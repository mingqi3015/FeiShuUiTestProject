#!/usr/bin/env python3
# coding:utf-8
"""
@File    : run.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.9
@contact: dominic3015@163.com
@Explain :
"""

from public_functions import log, wait, YamlOperation
from ui_test_project import base_driver

cookies = [{'domain': '.feishu.cn', 'expiry': 1700777960, 'httpOnly': True, 'name': 'sl_session', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': 'eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MDA3Nzc5NjAsInVuaXQiOiJldV9uYyIsInJhdyI6eyJtZXRhIjoiQVdWZXVUcjBDTUFEWlY2NUxOaktnQVJsWHljVUxRSEFBMlZmSnhRdEFjQURaVjhuSnFSRXdBTUNLZ0VBUVVGQlFVRkJRVUZCUVVKc1dIbGpiWE4zVVVGQmR6MDkiLCJzdW0iOiJhZmNlZTI5Y2JmZDYzY2JkYmE2NTNhZmQ2MDg1YjAyMzUxNWQ2MGFkZWUwNDhjMzAxM2JkZDUyYTcyMjAyODRkIiwibG9jIjoiemhfY24iLCJhcGMiOiJSZWxlYXNlIiwiaWF0IjoxNzAwNzM0NzYwLCJzYWMiOnsiVXNlclN0YWZmU3RhdHVzIjoiMSIsIlVzZXJUeXBlIjoiNDIifSwibG9kIjpudWxsLCJucyI6ImxhcmsiLCJuc191aWQiOiI3MzA0NDc5MzA4NDk0OTc5MDc1IiwibnNfdGlkIjoiNzMwNDQ3OTI0NzkwODM3MjQ4NCIsIm90IjoxfX0.jrVTFbk_E8XyG4x2wO_yH74AuDYzt92O-JcV0LNPmDPu7TM4vDUh5fptdQPCQqRWhvpzFGTTZXLAXYODVznpWA'}, {'domain': '.feishu.cn', 'expiry': 1702030759, 'httpOnly': True, 'name': 't_beda37', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': '727edddf962f11567d66d6779386182143ada41622e2d70c98f39565d4a2d6b8'}, {'domain': '.feishu.cn', 'expiry': 1702030759, 'httpOnly': False, 'name': 'swp_csrf_token', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': '638b25c1-0cf2-46dc-ba90-bee248474a12'}, {'domain': '.feishu.cn', 'httpOnly': False, 'name': 'Hm_lpvt_e78c0cb1b97ef970304b53d2097845fd', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '1700734760'}, {'domain': '.feishu.cn', 'expiry': 1732270758, 'httpOnly': True, 'name': 'session_list', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': 'XN0YXJ0-acdla867-2513-42de-b20e-d485186d04e1-WVuZA_XN0YXJ0-9e5i098c-4be0-4b68-87ca-6e241364c86a-WVuZA'}, {'domain': '.feishu.cn', 'expiry': 1732270758, 'httpOnly': True, 'name': 'session', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': 'XN0YXJ0-acdla867-2513-42de-b20e-d485186d04e1-WVuZA'}, {'domain': '.feishu.cn', 'expiry': 1735294760, 'httpOnly': False, 'name': '_ga', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': 'GA1.2.542046903.1700734739'}, {'domain': '.feishu.cn', 'expiry': 1732270739, 'httpOnly': True, 'name': 'passport_web_did', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': '7304600088226152451'}, {'domain': '.feishu.cn', 'expiry': 1732270741, 'httpOnly': False, 'name': 'locale', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': 'zh-CN'}, {'domain': '.feishu.cn', 'expiry': 1700734798, 'httpOnly': False, 'name': '_gat_UA-98246768-7', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '1'}, {'domain': '.feishu.cn', 'expiry': 1700907559, 'httpOnly': False, 'name': 'landing_url', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': 'https://www.feishu.cn/'}, {'domain': '.www.feishu.cn', 'expiry': 1701339538, 'httpOnly': False, 'name': '__tea_cookie_tokens_1658', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '%257B%2522web_id%2522%253A%25227304600026109298239%2522%252C%2522ssid%2522%253A%2522eab87bb2-d9b9-4e37-8b45-e2be584040e8%2522%252C%2522user_unique_id%2522%253A%25222559631700734737094%2522%252C%2522timestamp%2522%253A1700734738528%257D'}, {'domain': '.feishu.cn', 'expiry': 1735294742, 'httpOnly': True, 'name': 'trust_browser_id', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '906996ea-fc84-4bd3-b386-531d9ccb7ddb'}, {'domain': '.feishu.cn', 'expiry': 1732270739, 'httpOnly': True, 'name': 'QXV0aHpDb250ZXh0', 'path': '/', 'sameSite': 'None', 'secure': True, 'value': '8b8c6ac0d762492084513e7586f30885'}, {'domain': '.feishu.cn', 'expiry': 1732270759, 'httpOnly': False, 'name': 'Hm_lvt_e78c0cb1b97ef970304b53d2097845fd', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '1700734737'}, {'domain': '.feishu.cn', 'expiry': 1735294759, 'httpOnly': False, 'name': '_ga_VPYRHN104D', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': 'GS1.1.1700734738.1.1.1700734759.0.0.0'}, {'domain': '.feishu.cn', 'expiry': 1700821160, 'httpOnly': False, 'name': '_gid', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': 'GA1.2.80619786.1700734739'}, {'domain': '.feishu.cn', 'expiry': 1708510737, 'httpOnly': False, 'name': '__tea__ug__uid', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '2559631700734737094'}, {'domain': '.feishu.cn', 'expiry': 1708510738, 'httpOnly': False, 'name': '_gcl_au', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '1.1.1913838261.1700734738'}, {'domain': '.feishu.cn', 'expiry': 1703326734, 'httpOnly': True, 'name': '_uuid_hera_ab_path_1', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': '7304600064364675073'}, {'domain': '.feishu.cn', 'expiry': 1700821134, 'httpOnly': True, 'name': 'site_env', 'path': '/', 'sameSite': 'Lax', 'secure': False, 'value': 'pre=0'}]

feishu_data = YamlOperation('feishu_test_data.yaml').read_yaml_file()['feishu']
website = feishu_data['website']
username = feishu_data['username']
from ui_test_project.page.login_page import login_p

base_driver.open_browser()
base_driver.implicitly_wait(2)
log.debug('test')

base_driver.load_url(website)
wait(1)
base_driver.set_cookies(cookies)
base_driver.refresh_page()
# popup_is_display = base_driver.show_until_wait(login_p.popup_window, max_time=6)[0]
# if popup_is_display:
#     log.warning('有引流弹窗，需要先关闭弹窗才能进行操作')
#     base_driver.click(login_p.popup_close_btn)
#     log.info('引流弹窗关闭成功')
# log.info('点击登录按钮进入二维码登录界面')
# base_driver.click(login_p.login_btn)
# qr_code_is_exist = base_driver.show_until_wait(login_p.qr_code, max_time=10)[0]
# if qr_code_is_exist:
#     # 记录登录结果
#     result = False
#     # 20秒的循环每秒检测用户名是否出现，出现就停止
#     for i in range(0, 20):
#         log.debug('%d秒' % (20 - i))
#         # 获取用户名元素是否出现
#         if base_driver.show_until_wait(login_p.username, 1)[0]:
#             #获取用户名
#             username_bak = base_driver.get_text(login_p.username)
#             if username == username_bak:
#                 result = True
#             else:
#                 log.warning('登录成功，但是用户名不对，请检查')
#                 result = False
#             break
#         else:
#             result = False
#     if result:
#         log.info('扫码成功登录')
#     else:
#         log.ingo('20秒内扫码登录失败')
# else:
#     log.info('等待十秒未出现二维码，登录失败')
wait(2)
base_driver.refresh_page()
wait(10)
log.info('测试cookies')
base_driver.quit_browser_all()
