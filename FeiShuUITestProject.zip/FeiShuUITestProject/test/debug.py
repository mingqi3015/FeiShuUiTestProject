#!/usr/bin/env python3
# coding:utf-8
"""
@File    : debug.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.9
@contact: dominic3015@163.com
@Explain :
"""
print('%d秒'%1)