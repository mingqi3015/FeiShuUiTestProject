"""
------------------------------------
@Time : 2019/8/3 14:20
@Auth : 大锤
@File : WaitUntil.py
@IDE  : PyCharm
@Motto: Real warriors,dare to face the bleak warning,dare to face the incisive error!
------------------------------------
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import *
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait


class WaitUnit(object):
    def __init__(self, driver):
        self.byDic = {
            'id': By.ID,
            'name': By.NAME,
            'class_name': By.CLASS_NAME,
            'xpath': By.XPATH,
            'link_text': By.LINK_TEXT,
            'css': By.CSS_SELECTOR,
        }
        self.driver = driver

    def presence_of_element_located(self, by, locator, second=5):
        """显示等待某个元素出现在dom中，不一定可见，存在返回元素对象"""
        try:
            if by.lower() in self.byDic:
                WebDriverWait(self.driver, second).until(ec.presence_of_element_located((self.byDic[by.lower()], locator)))
            else:
                raise TypeError('未找到定位方式,请确保定位方式正确')
        except Exception as e:
            raise e

    def frame_to_be_available_and_switch_to_it(self, by, locator, second):
        """检查frame是否存在，存在就切换到frame中"""
        try:
            if by.lower() in self.byDic:
                WebDriverWait(self.driver, second).until(ec.frame_to_be_available_and_switch_to_it((self.byDic[by.lower()], locator)))
            else:
                raise TypeError('未找到定位方式,请确保定位方式正确')
        except Exception as e:
            raise e

    def visibility_of_element_located(self, by, locator, second):
        """显示等待页面元素出现在dom中， 并且可见， 存在则返回该元素对象"""
        try:
            if by.lower() in self.byDic:
                WebDriverWait(self.driver, second).until(ec.visibility_of_element_located((self.byDic[by.lower()], locator)))
            else:
                raise TypeError('未找到定位方式,请确保定位方式正确')
        except Exception as e:
            raise e

    def presence_of_alert_located(self, second=5):
        """显示等待alert出现"""
        try:
            WebDriverWait(self.driver, second).until(ec.alert_is_present())
        except TimeoutException as e:
            raise AssertionError('alert查找超时')
        except Exception as e:
            raise e


if __name__ == '__main__':
    d = webdriver.Chrome()
    d.get('http://www.146basejy.com/#/')
    wait = WaitUnit(d)
    d.quit()
