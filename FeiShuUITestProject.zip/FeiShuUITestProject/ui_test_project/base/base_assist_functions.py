#!/usr/bin/env python3
# coding=utf-8
"""
@File    : base_assist_functions.py
@Time    : 2022/1/1
@Author  : base_test
@Explain : 浏览器操作基类辅助函数集合
@Software: PyCharm
"""
import psutil
from public_functions.universal_functions import *
from public_functions.system_or_project_function import *
from public_functions.beautiful_log import log


def close_driver():
    """
    关闭浏览器驱动方法
    :return: 无
    """
    try:
        pids = psutil.pids()
        for pid in pids:
            p = psutil.Process(pid)
            if p.name() == 'chromedriver.exe':
                cmd = 'taskkill /IM chromedriver.exe /F'
                os.system(cmd)
        log.info('驱动程序关闭成功！')
    except Exception as e:
        log.info('驱动程序关闭成功！')


def find_all_element_click(driver):
    """
    寻找所有的可点击元素将背景颜色改为绿色，边框颜色改为蓝色
    :param driver: 当前浏览器驱动
    :return: 无
    """
    focus_style = "background: #97ec7e; border: 2px solid #4fc5c7;"  # 高亮的样式
    # links = []
    link_list = driver.find_elements_by_tag_name("input")
    link_list1 = driver.find_elements_by_tag_name("select")
    link_list2 = driver.find_elements_by_tag_name("span")
    # link_list4 = driver.find_elements_by_tag_name("div")
    for link in link_list:
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", link, focus_style)
        # log.info(link.get_attribute("href"))
        # links.append(link.get_attribute("src"))
    log.info('(绿色)可见可交互input数量-->' + str(len(link_list)))
    for link in link_list1:
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", link, focus_style)
        # log.info(link.get_attribute("href"))
        # links.append(link.get_attribute("src"))
    log.info('(绿色)可见可交互select数量-->' + str(len(link_list1)))
    for link in link_list2:
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", link, focus_style)
        # log.info(link.get_attribute("href"))
        # links.append(link.get_attribute("src"))
    log.info('(绿色)可见可交互span数量-->' + str(len(link_list2)))
    wait(0.2)


def find_all_img_links(driver):
    """
    查找所有的图片元素，将背景颜色改为橘色，边框蓝色
    :param driver: 浏览器驱动
    :return: 无
    """
    focus_style = "background: #dbf977; border: 2px solid #4fc5c7;"  # 高亮的样式
    links = []
    link_list = driver.find_elements_by_tag_name("img")
    for link in link_list:
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", link, focus_style)
        # log.info(link.get_attribute("href"))
        links.append(link.get_attribute("src"))
    log.info('(橘黄)可见可交互图片数量-->' + str(len(links)))
    wait(0.2)


def find_all_a_links(driver):
    """
    查找所有的链接元素，将背景颜色改为粉红色，边框蓝色
    :param driver: 浏览器驱动
    :return: 无
    """
    focus_style = "background: #fa6e86; border: 2px solid #4fc5c7;"  # 高亮的样式
    links = []
    link_list = driver.find_elements_by_tag_name("a")
    for link in link_list:
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", link, focus_style)
        # log.info(link.get_attribute("href"))
        links.append(link.get_attribute("href"))
    log.info('(粉红)可见可交互链接数量-->' + str(len(links)))
    wait(0.2)


def run_find_all_element(driver):
    """
    查找所有可操作性元素
    :param driver: 浏览器驱动
    :return: 无
    """
    try:
        find_all_element_click(driver)
        find_all_a_links(driver)
        find_all_img_links(driver)
        wait(0.5)
    except Exception as e:
        log.error(f'方法-run_find_all_element-执行错误，报错信息如下：' + str(e))
        raise e


def return_xpath(value):
    """
    xpath返回元素,默认返回的元素位置是第一个
    :param value: 可以是简单的文字或者xpath定位方式或者属性值等于什么(String类型)
    :return: 返回xpath定位方式（String类型）示例：//li[contains(text(),"密码登录")]
    :example:
        return_xpath('//*[@id="pane-account"]/input[1]')
        return_xpath('class="box-one"')
        return_xpath('登 录')
    """
    a = value.find('=')
    b = value.find('/')
    # 有等于又有斜线，表示100%是xpath直接返回即可
    if a != -1 and b != -1:
        return value
    # 没有斜线有等于表示某个属性等于某个值
    elif a != -1 and b == -1:
        return '//*[@{}]'.format(value)
    # 都没有时表示xpath利用文字查询查找
    elif a == -1 and b == -1:
        return '//*[text()="{}"]'.format(value)
    else:
        return value


def page_into_times(driver):
    """
    页面加载时间
    :param driver: 浏览器驱动(driver对象类型)
    :return:
    """
    navigation_start = driver.execute_script("return performance.timing.navigationStart")
    response_start = driver.execute_script("return performance.timing.responseStart")
    dom_complete = driver.execute_script("return performance.timing.loadEventEnd")
    # 计算
    backend_performance_calc = response_start - navigation_start  # TTFB（前端从服务端收到第一个字节的时间，也有人称白屏时间）
    frontend_performance_calc = dom_complete - response_start  # 前端加载页面时间
    dns_duration = driver.execute_script(
        "return (performance.timing.domainLookupEnd - performance.timing.domainLookupStart)")  # DNS查询时间
    tcp_duration = driver.execute_script(
        "return (performance.timing.connectEnd - performance.timing.connectStart)")  # TCP连接时间
    log.info('*' * 20)
    log.info('DNS查询时间时间: ' + str(dns_duration) + ' MS')
    log.info('TCP连接时间: ' + str(tcp_duration) + ' MS')
    log.info('TTFB(白屏时间): ' + str(backend_performance_calc) + ' MS')
    log.info('前端加载页面时间: ' + str(frontend_performance_calc) + ' MS')
    log.info('重定向耗时: ' + str(driver.execute_script("return performance.timing.redirectEnd") - driver.execute_script(
        "return performance.timing.redirectStart")) + ' MS')
    # print('TCP耗时:'+ str(a.execute_script("return performance.timing.connenctEnd") - a.execute_script("return performance.timing.connectStart")))
    # print('DNS耗时:'+ str(a.execute_script("return performance.timing.domainLookupEnd") - a.execute_script("return performance.timing.domainLookupStart")))
    log.info('接口请求耗时: ' + str(driver.execute_script("return performance.timing.responseStart") - driver.execute_script(
        "return performance.timing.requestStart")) + ' MS')
    log.info('页面渲染耗时: ' + str(driver.execute_script("return performance.timing.domComplete") - driver.execute_script(
        "return performance.timing.domLoading")) + ' MS')
    log.info('页面加载耗时: ' + str(driver.execute_script("return performance.timing.responseStart") - driver.execute_script(
        "return performance.timing.navigationStart")) + ' MS')
    log.info('*' * 20)


if __name__ == '__main__':
    print(return_xpath('登 录'))
