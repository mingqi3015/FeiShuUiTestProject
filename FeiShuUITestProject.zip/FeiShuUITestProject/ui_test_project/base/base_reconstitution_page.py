#!/usr/bin/env python3
# coding=utf-8
"""
@File    : base_reconstitution_page.py
@Time    : 2021/12/1
@Author  : base_test
@Software: PyCharm
@Explain : 浏览器操作基类重写，用于元素定位和操作等各种方法
"""

from helium import set_driver
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import *
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from ui_test_project1.base.WaitUntil import WaitUnit
from ui_test_project1.base.base_assist_functions import *
from public_functions.beautiful_log import log
from public_functions.system_or_project_function import get_system_type, get_config_value


# 重构元素查找类
class ReconstitutionBasePage:

    def __init__(self):
        self.windows_opt = None
        self.phone_opt = None
        self.driver = None
        self.waitUtil = None
        self.headless_mode = get_config_value('HEADLESS_MODE', 'is_open')

    def open_browser(self):
        """
        打开无痕浏览器驱动并开启最大化
        :return:
        """
        try:
            opt = webdriver.ChromeOptions()
            # 如果系统类型为linux则开启无头浏览器
            # headless为True代表开启无头浏览器窗口
            if self.headless_mode == 'open':
                opt.add_argument('--headless')
                opt.add_argument('--no-sandbox')
                opt.add_argument('--disable-gpu')
                opt.add_argument('--disable-dev-shm-usage')
            self.windows_opt = opt
            if get_system_type() == 'Linux':
                self.driver = webdriver.Chrome('/usr/bin/chromedriver', chrome_options=self.windows_opt)
            else:
                # 当设置为eager时,WebDriver 等到初始 HTML 文档完全加载和解析完毕，并放弃加载样式表、图像和子帧
                opt.page_load_strategy = 'eager'
                # 规避反爬selenium
                opt.add_experimental_option('excludeSwitches', ['enable-automation'])
                # opt.add_argument(r'--user-data-dir=D:\google\user_data')  # 设置用户文件夹，可免登陆
                opt.add_argument('--incognito')  # 进入隐身模式
                opt.add_argument('--disable-infobars')  # 禁用自动化控制程序的提示
                # opt.add_argument('--disable-gpu')  # 禁用GPU加速
                # opt.add_argument("blink-settings=imagesEnabled=false")  # 禁止加载图片
                opt.add_argument('--start-maximized')  # 启动时最大化
                opt.add_argument("--disable-extensions")  # 禁止插件
                opt.add_argument("--disable-software-rasterizer")
                opt.add_argument('--ignore-certificate-errors')
                opt.add_argument("--log-level=3")  # fatal
                prefs = {'credentials_enable_service': False, 'profile.password_manager_enabled': False}
                # 设置这两个参数就可以避免密码提示框的弹出
                opt.add_experimental_option('prefs', prefs)
                opt.add_experimental_option('w3c', True)
                self.driver = webdriver.Chrome(chrome_options=self.windows_opt)
            set_driver(self.driver)
            self.driver.maximize_window()
            # 最小化窗口通常会隐藏系统托盘中的窗口
            # driver.minimize_window()
            # log.info("本地窗口启动成功")
        except SessionNotCreatedException as e:
            # log.warning('打开浏览器窗口失败，将自动配置驱动，具体报错信息如下：' + str(e))
            self.open_browser_manager()
        except WebDriverException as e:
            # log.warning('打开浏览器窗口失败，将自动配置驱动，具体报错信息如下：' + str(e))
            self.open_browser_manager()
        except Exception as e:
            log.error('打开浏览器窗口失败，具体报错信息如下：' + str(e))
            raise e
        else:
            self.waitUtil = WaitUnit(self.driver)

    # 打开手机端浏览器
    def open_phone_browser(self):
        try:
            mobile_emulation = {'deviceName': 'iPhone X'}
            options = webdriver.ChromeOptions()
            # 如果系统类型为linux则开启无头浏览器
            # headless为True代表开启无头浏览器窗口
            if self.headless_mode == 'open':
                options.add_argument('--headless')
                options.add_argument('--no-sandbox')
                options.add_argument('--disable-gpu')
                options.add_argument('--disable-dev-shm-usage')
            options.add_experimental_option('mobileEmulation', mobile_emulation)

            self.phone_opt = options
            if get_system_type() == 'Linux':
                self.driver = webdriver.Chrome('/usr/bin/chromedriver', chrome_options=self.phone_opt)
            else:
                # 当设置为eager时,WebDriver 等到初始 HTML 文档完全加载和解析完毕，并放弃加载样式表、图像和子帧
                options.page_load_strategy = 'eager'
                options.add_experimental_option('w3c', False)
                options.add_experimental_option('useAutomationExtension', False)
                # 规避反爬selenium
                options.add_experimental_option('excludeSwitches', ['enable-automation'])
                options.add_argument('--incognito')  # 进入隐身模式
                options.add_argument('--disable-infobars')  # 禁用自动化控制程序的提示
                options.add_argument("--disable-software-rasterizer")
                options.add_argument("--disable-extensions")  # 禁止插件
                # 开发者模式
                # options.add_argument("--auto-open-devtools-for-tabs")
                self.driver = webdriver.Chrome(chrome_options=self.phone_opt)
            set_driver(self.driver)
            self.driver.maximize_window()
            log.info("本地手机窗口启动成功")
        except SessionNotCreatedException as e:
            # log.warning('打开手机窗口失败，可能是驱动版本不对，将自动配置驱动，具体报错信息如下：' + str(e))
            self.open_browser_manager(False)
        except WebDriverException as e:
            # log.warning('打开手机窗口失败，可能是驱动配置目录不对，将自动配置驱动，具体报错信息如下：' + str(e))
            self.open_browser_manager(False)
        except Exception as e:
            log.error('打开手机窗口失败，具体报错信息如下：' + str(e))
            raise e
        else:
            self.waitUtil = WaitUnit(self.driver)

    def open_browser_manager(self, chrome_type=True):
        """
        # 自动匹配谷歌驱动
        :param chrome_type: 默认为客户端类型，False代表手机类型
        :return:
        """
        try:
            if chrome_type:
                self.driver = webdriver.Chrome(ChromeDriverManager().install(), options=self.windows_opt)
            else:
                self.driver = webdriver.Chrome(ChromeDriverManager().install(), options=self.phone_opt)
            set_driver(self.driver)
            self.driver.maximize_window()
            # log.warning("自动匹配谷歌驱动并启动成功")
        except Exception as e:
            log.error('自动匹配谷歌驱动失败，具体报错信息如下：' + str(e))
            raise e
        else:
            self.waitUtil = WaitUnit(self.driver)

    def load_url(self, url):
        """
        输入网址并获取可操作性元素
        :param url: 访问的网址链接（String类型）
        :return: 无
        """
        try:
            self.driver.get(url)
            # log.info("请求地址:{}".format(url))
            # log.info('域名ip为：' + str(get_ip(url)))
            # 查找可操作元素
            # run_find_all_element(self.driver)
        except Exception as e:
            log.error(f'方法-load_url-执行错误，url--> {url}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def refresh_page(self):
        """刷新界面"""
        self.driver.refresh()

    def get_element_fuc(self, locator, is_plural=False, by=None):
        """
        获取可见元素方法
        :param is_plural: 是否查询多个元素，默认关闭（Boolean类型）
        :param locator: 定位方式的值，例如xpath的值：//li[contains(text(),"密码登录")]（String类型）
        :param by: 定位方式说明，例如：xpath、tag（String类型）
        :return: is_plural不传或者为False时返回一个元素(返回可操作元素)，为True时返回元素列表（List，列表内每一个元素都是可操作性元素）
        """
        if not locator:
            raise Exception('定位方式为空' + type(locator))
        try:
            if by is None:
                by = By.XPATH
            elif by == 'tag':
                by = By.TAG_NAME
            # 启用则调用查找多元素方法
            if is_plural:
                elements = WebDriverWait(
                    self.driver, 10, poll_frequency=0.1).until(
                    lambda x: x.find_elements(
                        by, locator))
                # true_list = []
                # for i in elements:
                #     # 可见
                #     # if i.is_displayed() and i.is_enabled():
                #     #     true_list.append(i)
                #     if i.is_displayed():
                #         true_list.append(i)
                return elements
            else:
                element = WebDriverWait(
                    self.driver, 10, poll_frequency=0.1).until(
                    lambda x: x.find_element(
                        by, locator))
                return element
                # 查找可见元素
                # if element.is_displayed():
                # else:
                #     raise Exception(f'方法-get_element_fuc-查找的元素不可见-->{locator}，无法操作')
        except TimeoutException as e:
            log.error(f'方法-get_element_fuc-查找元素超时-->{locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e
        except Exception as e:
            log.error(f'方法-get_element_fuc-没有找到元素-->{locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def auto_get_element_fuc(self, locator, is_plural=False):
        """
        根据传入自动查找xpath并返回定位到的具体元素
        :param is_plural: 是否查询多个元素，默认关闭（Boolean类型）
        :param locator: 元素定位表达式（String类型）,如果需要查找当前xpath下第几个元素则传入元组, 0开始
        示例1：'//*[@placeholder="账号/手机号"]'
        示例2：('//*[@placeholder="账号/手机号" ]', 0)
        :return: （元素对象）
        """

        focus_style = "background: #f03752; border: 2px solid red;"  # 高亮的样式
        try:
            if is_plural:
                locator1 = return_xpath(locator)
                # 获取元素列表
                element = self.get_element_fuc(locator1, is_plural=True)
                for item in element:
                    self.driver.execute_script(
                        "arguments[0].setAttribute('style', arguments[1]);", item, focus_style)
            elif type(locator) is tuple:
                locator1 = return_xpath(locator[0])
                # 获取元素列表
                element = self.get_element_fuc(locator1, is_plural=True)[int(locator[1])]
                self.driver.execute_script(
                    "arguments[0].setAttribute('style', arguments[1]);", element, focus_style)
            else:
                locator1 = return_xpath(locator)
                # 获取元素
                element = self.get_element_fuc(locator1)
                self.driver.execute_script(
                    "arguments[0].setAttribute('style', arguments[1]);", element, focus_style)
            return element
        except Exception as e:
            raise e

    def input_value(self, locator, value1, need_enter=False):
        """
        找到元素进行输入
        根据所传入的定位参数自动寻找xpath路径并找出列表，默认选中第一个元素进行输入；也可以直接传入xpath路径。
        :param need_enter: 是否需要自动添加回车键
        :param locator: 元素定位表达式（String类型）,如果需要查找当前xpath下第几个元素则传入元组
        示例1：'//*[@placeholder="账号/手机号"]'
        示例2：('//*[@placeholder="账号/手机号" ]', 0)
        :param value1: 需要输入的值（String类型）
        :return: 无
        """
        try:
            element = self.input_clear(locator)
            element.send_keys(value1)
            if need_enter:
                element.send_keys(Keys.ENTER)
            wait(0.1)
            # log.info("输入成功-->" + str(value1))
        except Exception as e:
            log.error(f'方法-input_value-元素-->{locator}输入{value1}失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def input_clear(self, locator):
        """
        找到元素进行输入
        根据所传入的定位参数自动寻找xpath路径并找出列表，默认选中第一个元素进行输入；也可以直接传入xpath路径。
        :param locator: 元素定位表达式（String类型）,如果需要查找当前xpath下第几个元素则传入元组
        示例1：'//*[@placeholder="账号/手机号"]'
        示例2：('//*[@placeholder="账号/手机号" ]', 0)
        :return: 无
        """
        element = self.click(locator, need_element=True)
        try:
            element.send_keys(Keys.CONTROL, "a")
            element.send_keys(Keys.DELETE)
            return element
        except Exception as e:
            log.error(f'方法-input_clear-元素-->{locator}清除失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def click(self, locator, need_log=True, need_element=False):
        """
        点击元素方法
        根据所传入的定位参数自动寻找xpath路径并找出列表，默认选中第一个元素进行点击；可以直接传入xpath路径。
        :param need_element: 为True则返回元素
        :param need_log: 试探性点击，失败之后不需要输出日志
        :param locator: 元素定位表达式（String类型）,如果需要查找当前xpath下第几个元素则传入元组
        示例1：'//*[@placeholder="账号/手机号"]'     这个默认等于下面那个
        示例2：('//*[@placeholder="账号/手机号" ]', 0)
        :return: 元素
        """
        element = self.auto_get_element_fuc(locator)
        try:
            element.click()
            wait(0.2)
        except ElementClickInterceptedException:
            # log.warning(f'方法-click-点击元素被拦截，使用元素穿透点击-->{locator}')
            self.driver.execute_script("arguments[0].click();", element)
            wait(0.2)
        except Exception as e:
            if need_log:
                log.error(f'方法-click-点击元素失败-->{locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
                raise e
        finally:
            if need_element:
                return element

    def get_page_url(self):
        """
        获取当前页面地址
        :return: 返回url（String类型）
        """
        try:
            value = self.driver.current_url
            # log.info('当前页面地址：{}'.format(value))
            return value
        except Exception as e:
            log.error(f'方法-get_page_url-报错误，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def back(self):
        try:
            self.driver.back()
            wait(1)
        except Exception as e:
            log.error(f'方法-back-报错，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def execute_js(self, js):
        """
        执行参数js代码
        :param js: js代码(String类型)
        :return: 无
        """
        try:
            return self.driver.execute_script(js)
            # log.info("JS执行成功")
        except Exception as e:
            log.error(f'方法-execute_js-执行js错误--> {js}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def execute_js_click(self, value):
        """
        js点击元素
        :param value: js定位
        :return: 无
        """
        js = "document.querySelector('%s').click();" % value
        try:
            self.driver.execute_script(js)
            # log.info("JS执行成功")
        except Exception as e:
            log.error(f'方法-execute_js_click-执行js错误--> {js}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def get_text(self, locator):
        """
        根据元素定位返回
        :param locator: 元素定位值
        :return: 返回获取到的文本（String类型）
        """
        try:
            text = self.auto_get_element_fuc(locator).text
            return text
        except Exception as e:
            log.error(f'方法-get_text-获取元素错误--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def get_size(self, locator):
        """
        根据元素定位返回元素宽高
        :param locator: 元素定位值(String类型)
        :return: 返回元素宽高（字典类型）示例：{'height': 36, 'width': 100}
        """
        try:
            size = self.auto_get_element_fuc(locator).size
            return size
        except Exception as e:
            log.error(f'方法-get_text-获取元素宽高失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def mouse_set_element(self, locator):
        """
        鼠标悬浮至元素之上
        :param locator: 元素定位表达式（String类型）
        :return: 无
        """
        try:
            element = self.auto_get_element_fuc(locator)
            ActionChains(self.driver).move_to_element(element).perform()
        except Exception as e:
            log.error(f'方法-mouse_set_element-鼠标移动悬浮到元素上失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def drag_element(self, locator1, locator2):
        """
        元素拖动，一个开始元素，一个结束元素位置
        :param locator1: 拖动的元素定位表达式（String类型）
        :param locator2: 拖动结束位置元素定位表达式（String类型）
        :return: 无
        """
        try:
            # 开始元素
            start_element = self.auto_get_element_fuc(locator1)
            # 需拖到只那个元素位置
            end_element = self.auto_get_element_fuc(locator2)
            ActionChains(self.driver).drag_and_drop(start_element, end_element).perform()
        except Exception as e:
            log.error(f'方法-drag_element-拖动元素--->{locator1}至元素--> {locator2}失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def drag_element_move_distance(self, locator, distance, direction=False):
        """
        拖动元素移动一定距离
        :param locator: 拖动的元素定位表达式（String类型）
        :param distance: 距离（Int类型）
        :param direction: 方向（Boolean类型）False横向
        :return: 无
        """
        try:
            # 操作元素
            element = self.auto_get_element_fuc(locator)
            action = ActionChains(self.driver)
            # text_direction = ''
            # 方向 False横向
            if direction:
                # text_direction = '纵向'
                action.drag_and_drop_by_offset(element, int(distance), 0).perform()
            else:
                # text_direction = '横向'
                action.drag_and_drop_by_offset(element, 0, int(distance)).perform()
            # log.info('元素{}，{}拖动{}成功'.format(locator, text_direction, str(distance)))
        except Exception as e:
            log.error(
                f'方法-drag_element_move_distance-拖动元素--->{locator}移动--> {distance}失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def double_click_element(self, locator):
        """
        鼠标左键双击元素
        :param locator: 元素定位表达式（String类型）
        :return: 无
        """
        try:
            element = self.auto_get_element_fuc(locator)
            ActionChains(self.driver).double_click(element).perform()
        except Exception as e:
            log.error(f'方法-double_click_element-鼠标左键双击元素失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    # 获取元素属性值
    def get_attribute(self, locator, name):
        try:
            attr = self.auto_get_element_fuc(locator).get_attribute(name)
            return attr
        except Exception as e:
            log.error(f'方法-get_attribute-获取元素属性值 {name} 失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    # 设置input框内的值
    def set_input_value(self, locator, value):
        try:
            element = self.auto_get_element_fuc(locator)
            self.driver.execute_script(
                "arguments[0].value=arguments[1];", element, value)
        except Exception as e:
            log.error(f'方法-set_input_value-设置输入框元素value值 {value} 失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def get_element_is_displayed(self, locator):
        """
        获取元素是否可见
        :param locator:
        :return:
        """
        try:
            element = self.auto_get_element_fuc(locator)
            return element.is_displayed()
        except Exception as e:
            log.error(f'方法-get_element_is_displayed-获取元素显示状态失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def get_element_is_enabled(self, locator):
        """
        获取元素是否可操作
        :param locator:
        :return:
        """
        try:
            element = self.auto_get_element_fuc(locator)
            return element.is_enabled()
        except Exception as e:
            log.error(f'方法-get_element_is_enabled-获取元素可操作状态失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def get_element_is_selected(self, locator):
        """
        获取元素是否被选中
        :param locator:
        :return:
        """
        try:
            element = self.auto_get_element_fuc(locator)
            return element.is_selected()
        except Exception as e:
            log.error(f'方法-get_element_is_selected-获取元素选中状态失败--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def scroll_move(self, element, distance, direction=True):
        """
        传入js定位方式定位元素控制滚动条的滚动
        :param element: js定位方式，示例：#pages > div.tool_bars > div.account_info > div > span.account_name（String类型）
        :param distance: 滚动距离（Float类型）
        :param direction: 不传值默认True,纵向;False为横向(Boolean类型)
        :return: 无
        """
        try:
            distance = str(float(distance))
        except Exception as e:
            raise e
        try:
            js = 'document.querySelector("' + element + '")'
            if direction:
                direction_str = '.scrollTop = ' + distance + ';'
            else:
                direction_str = '.scrollLeft = ' + distance + ';'
            js = js + direction_str
            self.execute_js(js)
        except Exception as e:
            raise e

    def change_handel(self, value=-1, close=False):
        """
        索引切换浏览器窗口,切换浏览器窗口，弹窗是内嵌窗口的话也可以使用，默认是0切换到浏览器默认窗口()第一个窗口，-1 是最新的窗口
        :param close: 是否关闭当前句柄
        :param value: 句柄下标，0是第一个也就是默认窗口，-1 代表最新窗口(Int类型)
        :return: 无
        """
        try:
            # log.info('当前句柄：' + str(now_handel))
            # 是否关闭窗口
            if close:
                self.driver.close()
            windows = self.driver.window_handles[int(value)]
            self.driver.switch_to.window(windows)
            # log.info('切换窗口成功')
            # page_into_times(self.driver)
        except Exception as e:
            log.error(f'方法-switch_to_index_window-执行错误，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def switch_to_content(self):
        """
        此方法用于从frame中切回主文档(switch_to.default_content()),嵌套frame的操作(switch_to.parent_frame())
        :return: 无
        """
        try:
            self.driver.switch_to.default_content()
            # log.info()("已切到顶层窗口")
        except Exception as e:
            log.error(f'方法-switch_to_content-执行错误，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def switch_to_frame(self, locator):
        """
        切换到frame里面
        :param locator: 定位路径，可以给xpath也可以给文字或者属性值，会自动获取xpath路径(String类型)
        :return: 无
        """
        try:
            # element = self.auto_get_element_fuc(locator)
            self.driver.switch_to.frame(locator)
            # log.info("切换frame成功")
        except Exception as e:
            log.error(f'方法-switch_to_frame-执行错误，locator--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def wait_presence_of_element_located(self, locator, by=None):
        """
        显示等待页面元素出现在DOM中，但并不一定可见
        :param locator: 显示等待的元素定位，默认xpath(String类型)
        :param by: 获取的方式, 支持xpath、id、css selector(String类型)
        :return: 无
        """
        try:
            by = self.get_all_location_fuc(by)
            self.waitUtil.presence_of_element_located(by, locator)
        except Exception as e:
            log.error(f'方法-wait_presence_of_element_located-执行错误，locator--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def wait_frame_to_be_available_and_switch_to_it(self, locator, by=None):
        """
        检查frame是否存在，存在就切换到frame中
        :param locator: 显示等待的元素定位，默认xpath(String类型)
        :param by: 获取的方式, 支持xpath、id、css selector(String类型)
        :return: 无
        """
        try:
            by = self.get_all_location_fuc(by)
            self.waitUtil.frame_to_be_available_and_switch_to_it(by, locator)
        except Exception as e:
            log.error(
                f'方法-wait_frame_to_be_available_and_switch_to_it-执行错误，locator--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(
                    e))
            raise e

    def wait_visibility_of_element_located(self, locator, by=None):
        """
        显示等待页面元素出现在DOM中，并且可见
        :param locator: 显示等待的元素定位，默认xpath(String类型)
        :param by: 获取的方式, 支持xpath、id、css selector(String类型)
        :return: 无
        """

        try:
            by = self.get_all_location_fuc(by)
            self.waitUtil.visibility_of_element_located(by, locator)
        except Exception as e:
            log.error(
                f'方法-wait_visibility_of_element_located-执行错误，locator--> {locator}，请前往查看日志详情复现问题,报错信息如下：' + str(
                    e))
            raise e

    def get_cookies(self):
        """
        :return: 当前标签cookies
        """
        return self.driver.get_cookies()

    def set_cookies(self, cookies):
        """
        :cookies: cookies列表
        :return:
        """
        for i in cookies:
            self.driver.add_cookie(i)



    def alert_accept(self):
        """
        系统弹窗确认
        :return:
        """
        try:
            # self.driver.switch_to_alert().accept() 废弃的方式
            self.waitUtil.presence_of_alert_located()
            alert = self.driver.switch_to.alert
            log.debug('弹窗内容为：' + alert.text)
            alert.accept()
        except Exception as e:
            log.error(f'方法-alert_accept-弹窗确认失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def alert_dismiss(self):
        """
        系统弹窗取消
        :return:
        """
        try:
            # driver.switch_to_alert().dismiss() #废弃的方式
            self.waitUtil.presence_of_alert_located()
            alert = self.driver.switch_to.alert
            log.debug('弹窗内容为：' + alert.text)
            alert.dismiss()
        except Exception as e:
            log.error(f'方法-alert_dismiss-弹窗取消失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def get_alert_text(self):
        """
        获取alert弹窗文本内容
        :return: 弹窗文本（String）
        """
        try:
            txt = self.driver.switch_to.alert.text()
            return txt
        except Exception as e:
            log.error(f'方法-get_alert_text-获取alert弹窗文本内容失败，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise e

    def open_new_label(self, url, need_change_handel=True):
        # 新开一个窗口
        js = 'window.open("%s");' % url
        self.driver.execute_script(js)
        if need_change_handel:
            self.change_handel()

    @staticmethod
    def get_all_location_fuc(by=None):
        """
        获取定位方式：示例：
        :param by: id
        :return: By.ID
        """
        # ID = "id"
        # XPATH = "xpath"
        # LINK_TEXT = "link text"
        # PARTIAL_LINK_TEXT = "partial link text"
        # NAME = "name"
        # TAG_NAME = "tag name"
        # CLASS_NAME = "class name"
        # CSS_SELECTOR = "css selector"
        if by == 'xpath' or by is None:
            locator = By.XPATH
        elif by == 'id':
            locator = By.ID
        elif by == 'css selector':
            locator = By.CSS_SELECTOR
        elif by == 'link text':
            locator = By.LINK_TEXT
        elif by == 'partial link text':
            locator = By.PARTIAL_LINK_TEXT
        elif by == 'name':
            locator = By.NAME
        elif by == 'tag name':
            locator = By.TAG_NAME
        elif by == 'class name':
            locator = By.CLASS_NAME
        else:
            # log.warning('不支持的定位方式：' + str(by))
            raise Exception('不支持的定位方式：' + str(by))
        return locator

    # 关闭当前标签页
    def close_this_tab(self):
        try:
            self.driver.close()
            # log.info("关闭当前标签页成功")
        except Exception as e:
            log.error(f'方法-close_this_tab-执行错误，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise Exception("关闭当前标签页失败,具体信息如下：" + str(e))

    def quit_browser_all(self):
        """
        关闭所有窗口
        :param driver: 浏览器驱动(driver对象类型)
        :return: 无
        """
        try:
            self.driver.quit()
            close_driver()
        except Exception as e:
            log.error('方法-run_find_all_element-执行错误，请前往查看日志详情复现问题,报错信息如下：' + str(e))
            raise Exception("关闭窗口失败,具体信息如下：" + str(e))

    def show_until_wait(self, locator, max_time=None, need_log=True):
        """
        显式等待存在且元素可见
        :param need_log: 是否需要日志
        :param locator: 元素
        :param max_time: 最长等待时间，默认为5秒
        :return: 元组类型，找到了返回True和元素定位方式，超时或者没找到返回False，其他情况报错（False, None）
        """
        if type(locator) is tuple:
            locator = return_xpath(locator[0])
        else:
            locator = return_xpath(locator)
        if max_time is None:
            max_time = 5
        else:
            max_time = float(max_time)
        try:
            self.waitUtil.visibility_of_element_located('xpath', locator, max_time)
            return True, locator
        except TimeoutException:
            if need_log:
                log.warning('显示等待元素超时，元素：{}，最大等待时间：{}'.format(locator, max_time))
            return False, None
        except NoSuchElementException:
            if need_log:
                log.warning('显示等待元素未找到元素，元素：{}，最大等待时间：{}'.format(locator, max_time))
            return False, None
        except Exception as e:
            if need_log:
                log.error(
                    '方法-show_until_wait-执行错误，元素：{}，最大等待时间：{}，请前往查看日志详情复现问题,报错信息如下：{}'.format(locator, max_time, str(e)))
            raise Exception("显示等待元素失败,具体信息如下：" + str(e))

    def show_until_wait_presence(self, locator, max_time=None, need_log=False):
        """
        显式等待存在但不一定可见
        :param need_log: 是否需要日志
        :param locator: 元素
        :param max_time: 最长等待时间，默认为5秒
        :return: 元组类型，找到了返回True和元素定位方式，超时或者没找到返回False，其他情况报错（False, None）
        """
        if type(locator) is tuple:
            locator = return_xpath(locator[0])
        else:
            locator = return_xpath(locator)
        if max_time is None:
            max_time = 5
        else:
            max_time = float(max_time)
        try:
            self.waitUtil.presence_of_element_located('xpath', locator, max_time)
            return True, locator
        except TimeoutException:
            if need_log:
                log.warning('显示等待元素超时，元素：{}，最大等待时间：{}'.format(locator, max_time))
            return False, None
        except NoSuchElementException:
            if need_log:
                log.warning('显示等待元素未找到元素，元素：{}，最大等待时间：{}'.format(locator, max_time))
            return False, None
        except Exception as e:
            if need_log:
                log.error(
                    '方法-show_until_wait-执行错误，元素：{}，最大等待时间：{}，请前往查看日志详情复现问题,报错信息如下：{}'.format(locator, max_time, str(e)))
            raise Exception("显示等待元素失败,具体信息如下：" + str(e))

    def implicitly_wait(self, second):
        """
        隐式等待
        :param second: 秒
        :return:
        """
        try:
            self.driver.implicitly_wait(second)
        except Exception as e:
            log.error('隐式等待失败-->implicitly_wait' + str(e))

    def selenium_driver_screenshot(self, screenshot_name=None):
        """
        selenium浏览器驱动截图
        :param screenshot_name: 截图名称（注意：不能给冒号）
        :return: filepath
        """
        try:
            this_time = get_current_time()
            if screenshot_name is None:
                pic_name = this_time
                pic_name += '.png'
            else:
                pic_name = screenshot_name
                if pic_name[-4:] != '.png':
                    pic_name += '.png'
            screenshot_directory = get_system_result_directory()['screenshot_directory']
            filepath = joint_path(screenshot_directory, pic_name)
            self.driver.get_screenshot_as_file(str(filepath))
            log.info('添加截图报告成功，截图路径：' + str(filepath))
            return filepath
        except Exception as e:
            log.error('函数-->selenium_driver_screenshot,添加截图报告失败，具体信息如下：' + str(e))
            raise e

        # # 滚动条拖动 direction：方向 不传值默认纵向，False为横向
        # def scroll_move(self, element, distance, direction=True):
        #     distance = str(distance)
        #     js = 'document.querySelector("' + element + '")'
        #     direction_str = ''
        #     if direction:
        #         direction_str = '.scrollTop = ' + distance + ';'
        #     else:
        #         direction_str = '.scrollLeft = ' + distance + ';'
        #     js = js + direction_str
        #     self.execute_js(js)


# 根据传参选择对应的选项（暂时只做选择值没有滚动条）
#     def select_value(self, kwargs):
#         # 示例参数
#         # service_data = {
#         #     'value': kwargs['service_area'], # 需要选择的参数
#         #     'options_js': 'body > div:nth-child(10) > div.el-scrollbar >'
#         #                   ' div.el-select-dropdown__wrap.el-scrollbar__wrap > ul > li', # 下拉列表的元素
#         #     'parent_ele': self.service_area_select # 点击展开列表的元素
#         # }
#         # 首先点击父元素展开选择项
#         if not self.click(kwargs['parent_ele']):
#             log.error('点击下拉选择框失败')
#             return False, '点击下拉选择框失败'
#         self.wait(1)
#         options_js = kwargs['options_js']
#         # 获取所有元素并将元素的文本放到一个数组里面，返回该元素的所有文字，数组类型
#         js_str = 'function getAllText(){' \
#                  'let arr = [];' \
#                  'document.querySelectorAll("' + options_js + '")' \
#                                                               '.forEach((item)=>{arr.push(item.innerText);});return arr;}' \
#                                                               'return getAllText();'
#
#         all_text = self.execute_js(js_str)
#         try:
#             # 获取需要的值所在列表的下标
#             index = all_text[1].index(kwargs['value']) + 1
#         except Exception as e:
#             log.error('获取选择元素失败')
#             log.error(e)
#             return False, '获取选择元素失败'
#         # 获取对应值的下标并点击该下标元素
#         select_option_js = kwargs['options_js'] + ":nth-child(" + str(index) + ")"
#         js_str2 = 'document.querySelector("' + select_option_js + '").click()'
#         return self.execute_js(js_str2)
#
#     # 获取指定元素的所有的值，children 为指定位置的，类型为数字默认没有
#     def get_selector_all_options(self, ele, children=None):
#         js = 'function getAllOptions(){' \
#              'let arr = [];' \
#              'document.querySelectorAll("' + ele + '")' \
#                                                    '.forEach((item, i)=>{let obj = {};obj.name = item'
#         if children is not None:
#             js += '.children[' + str(children) + ']'
#         js += '.innerText;' \
#               'obj.index = i;' \
#               'arr.push(obj)});' \
#               'return arr;}' \
#               'return getAllOptions();'
#         return self.execute_js(js)


base_driver = ReconstitutionBasePage()

if __name__ == '__main__':
    base_driver.open_browser()
    base_driver.load_url('http://www.146basejy.com/#/')
    base_driver.quit_browser_all()
