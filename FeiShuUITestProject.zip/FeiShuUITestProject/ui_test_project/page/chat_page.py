#!/usr/bin/env python3
# coding:utf-8
"""
@File    : chat_page.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.7
@contact: dominic3015@163.com
@Explain :
"""