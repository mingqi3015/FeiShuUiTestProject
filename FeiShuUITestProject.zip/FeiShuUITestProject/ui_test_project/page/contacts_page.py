#!/usr/bin/env python3
# coding:utf-8
"""
@File    : contacts_page.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.7
@contact: dominic3015@163.com
@Explain :
"""


class ContactsPage:

    @property
    def contacts_menu(self):
        """
         :return: 左侧通讯录菜单
        """
        return '//section[@class="nav-items"]/section[5]'

    @property
    def contacts_body(self):
        """
         :return: 右侧通讯录主体部分
        """
        return '//div[@class="contactPage"]'

    @property
    def search_body(self):
        """
         :return: 右侧通讯录搜索框触发部分
        """
        return '//div[@class="quick-jump-enter-com__box"]'

    @property
    def search_input(self):
        """
         :return: 右侧通讯录搜索输入部分
        """
        return '//input[@placeholder="查找会话、消息"]'

    @property
    def search_result(self):
        """
         :return: 右侧通讯录搜索结果第二条
        """
        return '//div[@class="quickJump_resultContainer"]/div[2]'


    @property
    def search_result_js(self):
        """
         :return: 右侧通讯录搜索结果第二条js结果
        """
        return 'div.quickJump_result > div > div:nth-child(2) > div'






contacts_p = ContactsPage()
