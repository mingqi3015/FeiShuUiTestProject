#!/usr/bin/env python3
# coding:utf-8
"""
@File    : message_page.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.7
@contact: dominic3015@163.com
@Explain :
"""


class MessagePage:

    @property
    def message_menu(self):
        """
         :return: 左侧消息菜单
        """
        return '//section[@class="nav-items"]/section[1]'

    @property
    def first_user(self):
        """
         :return: 聊天界面第一个用户
        """
        return '//div[@class="feedCard_item"][1]'

    @property
    def user_info(self):
        """
         :return: 聊天界面用户信息
        """
        return '//span[@class="chatWindow_groupName lark-drag-disable"]'

    @property
    def message_input(self):
        """
         :return: 聊天界面用户信息
        """
        return '//div[@class="lark-editor-container"]/div/pre'

    @property
    def messages_list(self):
        """
         :return: 聊天信息列表
        """
        return '//div[@class="message-section"]'

    @property
    def messages_list_item(self):
        """
         :return: 聊天信息的具体内容
        """
        return '//div[@class="message-section"]//span[@class="text-only "]'


message_p = MessagePage()
