#!/usr/bin/env python3
# coding:utf-8
"""
@File    : login_page.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.7
@contact: dominic3015@163.com
@Explain :
"""


class LoginPage:

    @property
    def popup_window(self):
        """
         :return:弹窗的xpath定位，用于检测是否有东西弹出，需要关闭
        """
        return '//div[@class="hc_Popup"]'

    @property
    def popup_close_btn(self):
        """
        :return: 弹窗关闭按钮
        """
        return '//div[@class="hc_Popup-content"]/div/div/div'

    @property
    def login_btn(self):
        """
        :return: 登录按钮
        """
        return '登录'

    @property
    def qr_code(self):
        """
        :return:二维码
        """
        return '//canvas'

    @property
    def username(self):
        """
        :return:用户名
        """
        return '//div[@class="_pp-header-name"]'

    @property
    def menu_btn(self):
        """
        :return: 主页弹窗菜单按钮
        """
        return '//span[@class="universe-icon _pp-product-icon"]'

    @property
    def message_options(self):
        """
        :return: 主页弹窗消息选项
        """
        return '//div[@title="消息"]'

login_p = LoginPage()
