#!/usr/bin/env python3
# coding=utf-8
"""
@File    : __init__.py
@Time    : 2022/3/9 19:03
@Author  : base_test
@Explain :
@Software: PyCharm
"""

from ui_test_project.base.base_reconstitution_page import base_driver, wait, log
