#!/usr/bin/env python3
# coding=utf-8
"""
@File    : conftest.py
@Time    : 2022/4/24 15:14
@Author  : base_test
@Explain : 全局配置
@Software: PyCharm
"""

import allure
import pytest
from ui_test_project import *
from ui_test_project.common_step import set_cookies


@pytest.fixture(scope='class')
def open_browser_and_close():
    """
    打开浏览器和关闭浏览器
    :return:
    """
    base_driver.open_browser()
    base_driver.implicitly_wait(2)
    yield
    base_driver.quit_browser_all()
    # data =


@pytest.fixture()
def set_cookies_fixture():
    """
    自动获取cookies并设置
    :return:
    """
    set_cookies()

@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    '''
    获取每个用例状态的钩子函数
    :param item:
    :param call:
    :return:
    '''
    # 获取钩子方法的调用结果
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call":
        screenshot_name = '用例失败截图'
    elif rep.when == "setup":
        screenshot_name = '前置操作失败截图'
    elif rep.when == "teardown":
        screenshot_name = '后置操作失败截图'
    else:
        screenshot_name = '其他操作失败截图'
    # 仅仅获取用例执行结果是失败的情况, 包含 setup/teardown，截图说明是什么情况下的失败截图
    if rep.failed:
        name = item.function.__name__
        with allure.step('添加失败截图...'):
            log.debug('用例：' + name + '执行失败，截图路径如下')
            try:
                file_path = base_driver.selenium_driver_screenshot()
            except:
                log.warning('警告，selenium截图失败')
            with open(file_path, mode='rb') as f:
                file = f.read()
                allure.attach(file, screenshot_name, allure.attachment_type.PNG)
