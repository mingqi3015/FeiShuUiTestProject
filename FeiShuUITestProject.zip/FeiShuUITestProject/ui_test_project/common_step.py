#!/usr/bin/env python3
# coding:utf-8
"""
@File    : common_step.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.9
@contact: dominic3015@163.com
@Explain :
"""
from public_functions import log, wait, YamlOperation
from ui_test_project import base_driver
from .page.login_page import login_p
feishu_data = YamlOperation('feishu_test_data.yaml').read_yaml_file()
website = feishu_data['website']
username = feishu_data['username']


def web_login():
    """
    web端的飞书登录通用
    :return: 登录的用户名
    """
    log.debug('test')
    base_driver.load_url(website)
    popup_is_display = base_driver.show_until_wait(login_p.popup_window, max_time=6)[0]
    if popup_is_display:
        log.warning('有引流弹窗，需要先关闭弹窗才能进行操作')
        base_driver.click(login_p.popup_close_btn)
        log.info('引流弹窗关闭成功')
    log.info('点击登录按钮进入二维码登录界面')
    base_driver.click(login_p.login_btn)
    qr_code_is_exist = base_driver.show_until_wait(login_p.qr_code, max_time=10)[0]
    if qr_code_is_exist:
        # 记录登录结果
        result = False
        # 20秒的循环每秒检测用户名是否出现，出现就停止
        for i in range(0, 20):
            log.debug('%d秒' % (20 - i))
            # 获取用户名元素是否出现
            if base_driver.show_until_wait(login_p.username, 1)[0]:
                result = True
                break
            else:
                result = False
        if result:
            log.info('扫码成功登录')
            cookies = base_driver.get_cookies()
            feishu_data['cookies'] = cookies
            YamlOperation('feishu_test_data.yaml').edit_yaml_file(feishu_data)
            log.info('cookies写入成功')
            log.info(feishu_data)
            username_bak = base_driver.get_text(login_p.username)
            return username_bak
        else:
            log.ingo('20秒内扫码登录失败')
            return ''
    else:
        log.info('等待十秒未出现二维码，登录失败')
        return ''


def set_cookies():
    base_driver.load_url(website)
    feishu_data = YamlOperation('feishu_test_data.yaml').read_yaml_file()
    base_driver.set_cookies(feishu_data['cookies'])
    base_driver.refresh_page()
    log.info('cookies设置完成并刷新成功')