#!/usr/bin/env python3
# coding:utf-8
"""
@File    : test_case_fei_shu.py
@Time    : 2023/11/23
@Author  : lijing
@Software: PyCharm
@version:  Python3.9
@contact: dominic3015@163.com
@Explain :
"""

import pytest
import allure
from ui_test_project.common_step import *
from public_functions import YamlOperation
from public_functions.helper import *
from ui_test_project.page.message_page import message_p
from ui_test_project.page.contacts_page import contacts_p

feishu_data = YamlOperation('feishu_test_data.yaml').read_yaml_file()
website = feishu_data['website']
username = feishu_data['username']


@pytest.mark.usefixtures('open_browser_and_close')
class TestCaseFeiShuClass:

    @allure.title('飞书登录测试')
    @allure.description('飞书扫码登录web端，登录进入，检测账号名称正确，即为登录成功')
    @pytest.mark.feishu
    def test_login(self):
        # 获取返回的用户名
        result = web_login()
        assert result == username, '用户名不一致，用例执行失败，请检查登录环境是否正常或者账号是否与数据中一致'

    @allure.title('飞书登录点击消息')
    @allure.description('飞书扫码登录后，点击进入消息界面则为成功')
    @pytest.mark.feishu
    @pytest.mark.usefixtures('set_cookies_fixture')
    def test_entrance_message_page(self):
        log.info('点击展开菜单')
        base_driver.click(login_p.menu_btn)
        log.info('点击消息按钮')
        base_driver.click(login_p.message_options)
        log.info('切换最新的句柄')
        base_driver.change_handel()
        # 找到左边的消息菜单进行断言
        message_menu_is_exist = base_driver.show_until_wait(message_p.message_menu)[0]
        # 截图按需开启
        # base_driver.selenium_driver_screenshot()
        assert message_menu_is_exist, '没找到消息左侧菜单，用例执行失败'

    @allure.title('飞书登录进入通讯录界面')
    @allure.description('飞书扫码登录后，点击进入通讯录界面则为成功')
    @pytest.mark.feishu
    @pytest.mark.usefixtures('set_cookies_fixture')
    def test_entrance_contacts_page(self):
        log.info('点击展开菜单')
        base_driver.click(login_p.menu_btn)
        log.info('点击消息按钮')
        base_driver.click(login_p.message_options)
        log.info('切换最新的句柄')
        base_driver.change_handel()
        log.info('点击通讯录按钮')
        base_driver.click(contacts_p.contacts_menu)
        # 找到右边通讯录主题菜单进行断言
        message_menu_is_exist = base_driver.show_until_wait(contacts_p.contacts_body)[0]
        # 截图按需开启
        base_driver.selenium_driver_screenshot()
        assert message_menu_is_exist, '没找到通讯录右侧主题，用例执行失败'

    @allure.title('飞书登录找到tester2进入聊天界面')
    @allure.description('飞书扫码登录后，点击进入tester2聊天界面则为成功')
    @pytest.mark.feishu
    @pytest.mark.usefixtures('set_cookies_fixture')
    def test_entrance_chat_page(self):
        log.info('点击展开菜单')
        base_driver.click(login_p.menu_btn)
        log.info('点击消息按钮')
        base_driver.click(login_p.message_options)
        log.info('切换最新的句柄')
        base_driver.change_handel()
        wait(5)
        log.info('点击通讯录按钮')
        base_driver.click(contacts_p.contacts_menu)
        log.info('点击搜索触发按钮')
        base_driver.click(contacts_p.search_body)
        log.info('输入需要查找的用户名，并输入回车')
        base_driver.input_value(contacts_p.search_input, feishu_data['chat_object'])
        log.info('等待三秒将用户信息刷新出来')
        wait(3)
        log.info('点击搜索的结果，进入聊天界面')
        base_driver.click(contacts_p.search_result)
        # 截图按需开启
        # base_driver.selenium_driver_screenshot()
        # 找到右边通讯录主题菜单进行断言
        base_driver.show_until_wait(message_p.user_info)
        user_info = base_driver.get_text(message_p.user_info)
        assert user_info == feishu_data['chat_object'], '跳转进入消息界面用户信息对不上，用例执行失败'

    @allure.title('飞书登录找到tester2进入聊天界面发送消息')
    @allure.description('飞书扫码登录后，点击进入tester2聊天界面发送消息则为成功')
    @pytest.mark.feishu
    @pytest.mark.usefixtures('set_cookies_fixture')
    def test_chat(self):
        log.info('点击展开菜单')
        base_driver.click(login_p.menu_btn)
        log.info('点击消息按钮')
        base_driver.click(login_p.message_options)
        log.info('切换最新的句柄')
        base_driver.change_handel()
        wait(5)
        log.info('点击通讯录按钮')
        base_driver.click(contacts_p.contacts_menu)
        log.info('点击搜索触发按钮')
        base_driver.click(contacts_p.search_body)
        log.info('输入需要查找的用户名，并输入回车')
        base_driver.input_value(contacts_p.search_input, feishu_data['chat_object'])
        log.info('等待三秒将用户信息刷新出来')
        wait(3)
        log.info('点击搜索的结果，进入聊天界面')
        base_driver.click(contacts_p.search_result)
        # 等待用户信息出来然后发送信息
        base_driver.show_until_wait(message_p.user_info)
        log.info('设置对应文字进行输入')
        base_driver.input_value(message_p.message_input, feishu_data['message_content'], True)
        # 等待发送完成之后进行检查
        wait(2)
        #获取最新一条信息的内容进行对比
        last_index = len(base_driver.get_element_fuc(message_p.messages_list, True)) - 1
        result = base_driver.get_text((message_p.messages_list_item, last_index))
        # 截图按需开启
        base_driver.selenium_driver_screenshot()
        assert result == feishu_data['message_content'], '跳转进入消息界面用户信息对不上，用例执行失败'


if __name__ == '__main__':
    pytest.main(['test_case_fei_shu.py', '-m=feishu'])
