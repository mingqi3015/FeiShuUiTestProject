#!/usr/bin/env python3
# coding=utf-8
"""
@File    : txt_operation.py
@Time    : 2022/1/1
@Author  : base_test
@Explain : txt文件操作类
@Software: PyCharm
"""


class TxtOperation:
    """
    txt文件操作类
    """
    def __init__(self, filepath):
        """
        文件路径
        :param filepath:
        """
        self.filepath = filepath

    def get_txt(self):
        """
        获取txt文件内容
        :return: 文件内容
        """
        try:
            with open(self.filepath, 'r', encoding='utf8') as f:
                data = f.read()
                f.close()
                return data
        except Exception as e:
            raise e

    def write_txt(self, content, isappend=False):
        """
        覆盖或者追加txt文件内容
        :param content: 写入参数
        :param isappend: Flase为覆盖模式，True为追加模式
        :return: 返回无
        """
        try:
            if isappend:
                mode = 'a'
            else:
                mode = 'w'
            with open(self.filepath, mode, encoding='utf8') as f:
                f.write(content)
                f.close()
        except Exception as e:
            raise e


if __name__ == '__main__':
    txt = TxtOperation('..\\files\\txt_files\\1.txt')
    txt.get_txt()
    txt.write_txt('新年快乐', isappend=True)
