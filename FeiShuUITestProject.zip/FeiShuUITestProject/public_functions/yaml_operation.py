#!/usr/bin/env python3
# coding=utf-8
"""
@File    : yaml_operation
@Time    : 2021/12/30
@Author  : bese_test
@Explain : yaml文件操作类
@Software: PyCharm
"""

import yaml
from public_functions.system_or_project_function import *
from public_functions.beautiful_log import log


class YamlOperation:
    """
        filepath: 不能为空，文件路径
    """

    def __init__(self, filename, custom_path=None):
        """
        初始化
        :param filename: 文件名
        :param custom_path:
        """
        if custom_path:
            self.filepath = custom_path
        else:
            self.filepath = get_files_path() + "yaml_files\\" + filename

    # 读取yaml文件
    def read_yaml_file(self):
        """
        :return: json格式的内容
        """
        try:
            with open(self.filepath, 'r', encoding='utf8') as f:
                data = f.read()
                data = yaml.load(data, Loader=yaml.Loader)
                f.close()
                return data
        except Exception as e:
            log.error('读取yaml文件失败，报错信息如下：' + str(e))

    # 修改yaml文件
    def edit_yaml_file(self, new_data):
        """
        :param new_data: 需要将内容修改为什么样子的参数
        :return: 无
        """
        try:
            with open(self.filepath, 'w', encoding='utf8') as f:
                #
                yaml.dump(new_data, f, allow_unicode=True)
                f.close()
        except Exception as e:
            log.error('修改yaml文件失败，报错信息如下：' + str(e))


if __name__ == '__main__':
    feishu_test_data = YamlOperation('feishu_test_data.yaml').read_yaml_file()
    print(feishu_test_data)