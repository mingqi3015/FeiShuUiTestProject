#!/usr/bin/env python3
# coding=utf-8
"""
@File    : excel_operation.py
@Time    : 2021/12/30
@Author  : bese_test
@Explain : excel文件操作类
@Software: PyCharm
"""

import json
from xlrd import open_workbook
from openpyxl import *
from public_functions.beautiful_log import log



class createExcel():
    '''创建excel表'''
    def __init__(self):
        self.wb = Workbook()

    def create(self,value,num = None):
        '''创建工作表(num默认为，创建的工作表在最后面)'''
        self.wb.create_sheet(value,num)
        ws = self.wb.active
        print(ws)



class parseExcel():
    '''解析excel表'''
    def __init__(self,path = None):
        if path == None:
            print("[info:输入文件路径及文件名]")
            self.wk = None
            return
            # sys.exit()  # 文件名为空时结束执行
        else:
            self.wk = load_workbook(path)
            self.path = path

    def sheetName(self):
        '''获取excel表所有的sheet名'''
        if self.wk == None:
            return
        sheetname = self.wk.sheetnames
        print("sheet数量：%s\nsheet:%s" % (len(sheetname), sheetname))

    def getsheetName(self,sheetname = None):
        """获取sheet对象"""
        if self.wk == None:
            return None
        if sheetname == None:   # sheetname为空时默认取文件的第一个sheet
            sheetnames = self.wk.sheetnames[0]
            sheet = self.wk[sheetnames]
            return sheet
        try:
            sheets = self.wk[sheetname]
            return sheets
        except Exception as e:
            log.error(e)
            return None

    def getlinenum(self,sheet = None):
        """获取有效数据的最大行号"""
        return self.getsheetName(sheet).max_row

    def getcolumnnum(self,sheet = None):
        """获取有效数据的最大列号"""
        return self.getsheetName(sheet).max_column

    def getcolumnvalues(self,columnnum,sheet = None):
        '''获取某一列的数据'''
        maxlinNum = self.getlinenum(sheet)
        columnvalunes = []
        for num in range(1,maxlinNum+1):
            value = self.getsheetName(sheet).cell(num,columnnum).value
            if value is None:
                value = ""
            columnvalunes.append(value)
        return columnvalunes

    def getlinevalues(self,linenum,sheet = None):
        '''获取某一行的数据'''
        maxcolumnNum = self.getcolumnnum(sheet)
        linvalunes = []
        for num in range(1,maxcolumnNum+1):
            value = self.getsheetName(sheet).cell(linenum,num).value
            if value is None:
                value = ""
            linvalunes.append(value)
        return linvalunes

    def getvalue(self,num1,sheet = None):
        '''获取某一个单元格的值或多个值'''
        sheet = self.getsheetName(sheet)
        value = sheet[num1].value
        return value

    def write_excel(self,cvalue,r,c,sheet = None):
        """将值写入单元格"""
        sheets = self.getsheetName(sheet)
        sheets.cell(row = r,column =c ).value = cvalue
        self.wk.save(self.path)
        log.info("info:写入文件成功，写入内容{}" .format(cvalue))

    def getallvalues(self,lines = 1,columns = 1,sheet = None):
        '''默认获取sheet页的所有数据，可以指定从某一行或某一列获取'''
        maxlinNum = self.getlinenum(sheet)
        maxcolumnNum = self.getcolumnnum(sheet)
        allvalue = []
        for lin in range(lines,maxlinNum+1):
            linvalue = []
            for column in range(columns,maxcolumnNum+1):
                value =  self.getsheetName(sheet).cell(lin,column).value
                if value is None:
                    value = ""
                linvalue.append(value)
            allvalue.append(tuple(linvalue))
        return allvalue

    def copy_excel(self,excelpath1,sheet = None):
        '''复制excel，到指定文件夹'''
        wk1 = Workbook()
        wk1.save(excelpath1)
        wk1 = load_workbook(excelpath1)
        wk1sheet = wk1.sheetnames[0]
        sheet1 = wk1[wk1sheet]
        maxlinNum = self.getlinenum(sheet)
        maxcolumnNum = self.getcolumnnum(sheet)
        for lin in range(1, maxlinNum + 1):
            for column in range(1,maxcolumnNum+1):
                values =  self.getsheetName(sheet).cell(lin,column).value
                sheet1.cell(lin,column).value = values
        wk1.save(excelpath1)  # 保存数据
        wk1.close()  # 关闭excel
        log.info('[info:复制文件成功，复制文件path：{}]'.format(excelpath1))


    def getallvalues_api(self,sheet = None):
        '''默认获取sheet页的所有数据，第一行的值作为key,以字典格式输出，用于接口测试'''
        maxlinNum = self.getlinenum(sheet)
        if maxlinNum <= 1:
            log.info("文件总行数小于1")
        else:
            allvalue = []
            lin_1 = self.getlinevalues(1)
            for lin in range(2,maxlinNum+1):
                value = self.getlinevalues(lin)
                linvalues = dict(zip(lin_1,value))
                linvalues["rowNum"] = lin
                allvalue.append(linvalues)
            return allvalue


# excel用例读取
def get_xls(xls_name, sheet_name):
    param = []
    # 打开excel文件
    file = open_workbook("./data/" + xls_name)
    # 获取sheet名称
    sheet = file.sheet_by_name(sheet_name)
    title = []
    # 循环行
    for i in range(sheet.nrows):
        # 根据第一行第一个是不是case_id判断是不是表头，是表头则添加数据
        if sheet.row_values(i)[0] != 'case_id':
            item = {}
            # 循环列
            for index in range(len(sheet.row_values(i))):
                # 将需要的数据json转义一下
                # case_params代表拼接在url后面的参数，case_headers代表请求头，case_msg代表响应状态码，precondition代表获取公共参数里面的值并拼接到json请求参数中，
                # preset_function代表请求这个接口之前需要做的操作，请求公共api里面的接口，case_json是json格式的请求参数，当这些值为空的时候默认给个{}
                if (title[index] == 'case_params' or title[index] == 'case_headers' or title[index] == 'case_msg' or
                    title[index] == 'precondition' or title[index] == 'preset_function') or \
                        title[index] == 'case_json' and sheet.row_values(i)[index]:
                    try:
                        if sheet.row_values(i)[index]:
                            item[title[index]] = json.loads(sheet.row_values(i)[index], strict=False)
                        else:
                            item[title[index]] = {}
                    except:
                        log.error('json解析出错了')
                        log.error(sheet.row_values(i)[index])
                else:
                    item[title[index]] = sheet.row_values(i)[index]
            param.append(item)
        # 是表头则直接将表头统计出来
        else:
            title = sheet.row_values(i)
    return param
