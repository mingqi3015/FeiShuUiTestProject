#!/usr/bin/env python3
# coding=utf-8
"""
@File    : Beautiful.py
@Time    : 2021/12/30
@Author  : bese_test
@Explain : 美化日志类
@Software: PyCharm
"""
# import logging
# from logging.handlers import RotatingFileHandler  # 按文件大小滚动备份
# import colorlog
# import time
# import traceback
# import os
#
#
# # 美化日志输出
# class BeautifulLog:
#     def __init__(self):
#         debug = 'cyan'
#         info = 'green'
#         warning = 'yellow'
#         error = 'purple'
#         critical = 'red'
#         # 日志颜色配置
#         log_colors_config = {
#             'DEBUG': debug,
#             'INFO': info,
#             'WARNING': warning,
#             'ERROR': error,
#             'CRITICAL': critical,
#         }
#         # 获取日志存放路径
#         cur_path = os.path.abspath(os.path.dirname(__file__))
#         root_path = os.path.dirname(cur_path)
#         dirname = os.path.join(root_path, 'UI_TEST_RESULT')
#         logs_directory = os.path.join(dirname, 'logs')
#         logs_is_exist = os.path.isdir(logs_directory)
#         if not logs_is_exist:
#             os.makedirs(logs_directory)
#         # 文件的命名
#         self.log_name = os.path.join(logs_directory, '%s.log' % time.strftime('%Y-%m-%d'))
#         self.logger = logging.getLogger()
#         self.logger.setLevel(logging.ERROR)
#         self.formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')  # 日志输出格式
#
#     def __console(self, level, message):
#         # 创建一个FileHandler，用于写到本地
#         fh = RotatingFileHandler(filename=self.log_name, mode='a', maxBytes=1024 * 1024 * 5, backupCount=5,
#                                  encoding='utf-8')  # 使用RotatingFileHandler类，滚动备份日志
#         fh.setLevel(logging.DEBUG)
#         fh.setFormatter(self.formatter)
#         self.logger.addHandler(fh)
#
#         # 创建一个StreamHandler,用于输出到控制台
#         ch = colorlog.StreamHandler()
#         ch.setLevel(logging.DEBUG)
#         ch.setFormatter(self.formatter)
#         self.logger.addHandler(ch)
#
#         if level == 'info':
#             self.logger.info(message)
#         elif level == 'debug':
#             self.logger.debug(message)
#         elif level == 'warning':
#             self.logger.warning(message)
#         elif level == 'error':
#             self.logger.error(message)
#         # 这两行代码是为了避免日志输出重复问题
#         self.logger.removeHandler(ch)
#         self.logger.removeHandler(fh)
#         fh.close()  # 关闭打开的文件
#
#     def debug(self, message):
#         self.__console('debug', message)
#
#     def info(self, message):
#         self.__console('info', message)
#
#     def warning(self, message):
#         self.__console('warning', message)
#
#     def error(self, message):
#         data = traceback.format_exc()
#         self.__console('error', str(message) + str(data if data is not None else ''))
#
#
# log = BeautifulLog()
#
# if __name__ == '__main__':
#     # log.debug('测试')
#     log.warning('嘿哈')

import logging
from logging.handlers import RotatingFileHandler  # 按文件大小滚动备份
import time
import os
from public_functions.system_or_project_function import get_root_path, joint_path


# 美化日志输出
class MyLogger(logging.Logger):
    def __init__(self):
        # 获取项目存放日志路径
        root_path = get_root_path()
        logs_directory = joint_path(root_path, 'UI_TEST_RESULT')
        logs_directory = joint_path(logs_directory, 'logs')
        # 获取日期用于日志命令
        log_name = time.strftime('%Y-%m-%d')
        level = 'INFO'
        log_name = os.path.join(logs_directory, '%s.log' % log_name)

        # 判断日志文件是否存在，不存在则新建
        logs_is_exist = os.path.isdir(logs_directory)
        if not logs_is_exist:
            os.makedirs(logs_directory)
        # 设置日志文件名及路径等级
        super(MyLogger, self).__init__(log_name, level)
        fmt = '%(asctime)s %(filename)s line %(lineno)d %(levelname)s：%(message)s'
        formatter = logging.Formatter(fmt, '%H:%M:%S')  # 日志输出格式

        # 控制台输出
        terminal_handle = logging.StreamHandler()
        terminal_handle.setFormatter(formatter)
        self.addHandler(terminal_handle)

        # 创建一个FileHandler，用于写到本地
        file_handle = RotatingFileHandler(filename=log_name, mode='a', maxBytes=1024 * 1024 * 5, backupCount=5,
                                          encoding='utf-8')  # 使用RotatingFileHandler类，滚动备份日志
        file_handle.setFormatter(formatter)
        self.addHandler(file_handle)
        file_handle.close()  # 关闭打开的文件


log = MyLogger()

if __name__ == '__main__':
    log.info('嘿哈')
