#!/usr/bin/env python3
# coding=utf-8
"""
@File    : keyboard_operation.py
@Time    : 2022/1/1
@Author  : base_test
@Explain : 键盘操作事件
@Software: PyCharm
"""

import win32api
import win32con
'''
perform()： 执行所有 ActionChains 中存储的行为；
context_click()： 右击；
double_click()： 双击；
drag_and_drop()： 拖动；
move_to_element()： 鼠标悬停

#下面是一些常用的键盘事件： 
# Keys.BACK_SPACE：回退键（BackSpace）
# Keys.TAB：制表键（Tab）
# Keys.ENTER：回车键（Enter）
# Keys.SHIFT：大小写转换键（Shift）
# Keys.CONTROL：Control键（Ctrl）
# Keys.ALT：ALT键（Alt）
# Keys.ESCAPE：返回键（Esc）
# Keys.SPACE：空格键（Space）
# Keys.PAGE_UP：翻页键上（Page Up）
# Keys.PAGE_DOWN：翻页键下（Page Down）
# Keys.END：行尾键（End）
# Keys.HOME：行首键（Home）
# Keys.LEFT：方向键左（Left）
# Keys.UP：方向键上（Up）
# Keys.RIGHT：方向键右（Right）
# Keys.DOWN：方向键下（Down）
# Keys.INSERT：插入键（Insert）
# DELETE：删除键（Delete）
# NUMPAD0 ~ NUMPAD9：数字键1-9
# F1 ~ F12：F1 - F12键
# (Keys.CONTROL, ‘a’)：组合键Control+a，全选
# (Keys.CONTROL, ‘c’)：组合键Control+c，复制
# (Keys.CONTROL, ‘x’)：组合键Control+x，剪切
# (Keys.CONTROL, ‘v’)：组合键Control+v，粘贴
'''


class KeyBoardKeys(object):
    """模拟键盘"""
    vk_code = {
        'backspace': 0x08,
        'tab': 0x09,
        'clear': 0x0C,
        'enter': 0x0D,
        'shift': 0x10,
        'ctrl': 0x11,
        'alt': 0x12,
        'pause': 0x13,
        'caps_lock': 0x14,
        'esc': 0x1B,
        'spacebar': 0x20,
        'page_up': 0x21,
        'page_down': 0x22,
        'end': 0x23,
        'home': 0x24,
        'left_arrow': 0x25,
        'up_arrow': 0x26,
        'right_arrow': 0x27,
        'down_arrow': 0x28,
        'select': 0x29,
        'print': 0x2A,
        'execute': 0x2B,
        'print_screen': 0x2C,
        'ins': 0x2D,
        'del': 0x2E,
        'help': 0x2F,
        '0': 0x30,
        '1': 0x31,
        '2': 0x32,
        '3': 0x33,
        '4': 0x34,
        '5': 0x35,
        '6': 0x36,
        '7': 0x37,
        '8': 0x38,
        '9': 0x39,
        'a': 0x41,
        'b': 0x42,
        'c': 0x43,
        'd': 0x44,
        'e': 0x45,
        'f': 0x46,
        'g': 0x47,
        'h': 0x48,
        'i': 0x49,
        'j': 0x4A,
        'k': 0x4B,
        'l': 0x4C,
        'm': 0x4D,
        'n': 0x4E,
        'o': 0x4F,
        'p': 0x50,
        'q': 0x51,
        'r': 0x52,
        's': 0x53,
        't': 0x54,
        'u': 0x55,
        'v': 0x56,
        'w': 0x57,
        'x': 0x58,
        'y': 0x59,
        'z': 0x5A,
        'numpversion.infoad_0': 0x60,
        'numpad_1': 0x61,
        'numpad_2': 0x62,
        'numpad_3': 0x63,
        'numpad_4': 0x64,
        'numpad_5': 0x65,
        'numpad_6': 0x66,
        'numpad_7': 0x67,
        'numpad_8': 0x68,
        'numpad_9': 0x69,
        'multiply_key': 0x6A,
        'add_key': 0x6B,
        'separator_key': 0x6C,
        'subtract_key': 0x6D,
        'decimal_key': 0x6E,
        'pide_key': 0x6F,
        'F1': 0x70,
        'F2': 0x71,
        'F3': 0x72,
        'F4': 0x73,
        'F5': 0x74,
        'F6': 0x75,
        'F7': 0x76,
        'F8': 0x77,
        'F9': 0x78,
        'F10': 0x79,
        'F11': 0x7A,
        'F12': 0x7B,
        'F13': 0x7C,
        'F14': 0x7D,
        'F15': 0x7E,
        'F16': 0x7F,
        'F17': 0x80,
        'F18': 0x81,
        'F19': 0x82,
        'F20': 0x83,
        'F21': 0x84,
        'F22': 0x85,
        'F23': 0x86,
        'F24': 0x87,
        'num_lock': 0x90,
        'scroll_lock': 0x91,
        'left_shift': 0xA0,
        'right_shift ': 0xA1,
        'left_control': 0xA2,
        'right_control': 0xA3,
        'left_menu': 0xA4,
        'right_menu': 0xA5,
        'browser_back': 0xA6,
        'browser_forward': 0xA7,
        'browser_refresh': 0xA8,
        'browser_stop': 0xA9,
        'browser_search': 0xAA,
        'browser_favorites': 0xAB,
        'browser_start_and_home': 0xAC,
        'volume_mute': 0xAD,
        'volume_Down': 0xAE,
        'volume_up': 0xAF,
        'next_track': 0xB0,
        'previous_track': 0xB1,
        'stop_media': 0xB2,
        'play/pause_media': 0xB3,
        'start_mail': 0xB4,
        'select_media': 0xB5,
        'start_application_1': 0xB6,
        'start_application_2': 0xB7,
        'attn_key': 0xF6,
        'crsel_key': 0xF7,
        'exsel_key': 0xF8,
        'play_key': 0xFA,
        'zoom_key': 0xFB,
        'clear_key': 0xFE,
        '+': 0xBB,
        ',': 0xBC,
        '-': 0xBD,
        '.': 0xBE,
        '/': 0xBF,
        '`': 0xC0,
        ';': 0xBA,
        '[': 0xDB,
        '//': 0xDC,
        ']': 0xDD,
        "'": 0xDE,
    }

    @staticmethod
    def key_down(key_name):
        """模拟按下键"""
        try:
            win32api.keybd_event(KeyBoardKeys.vk_code[key_name], 0, 0, 0)
        except Exception as e:
            raise e

    @staticmethod
    def key_up(key_name):
        """释放键"""
        try:
            win32api.keybd_event(KeyBoardKeys.vk_code[key_name], 0, win32con.KEYEVENTF_KEYUP, 0)
        except Exception as e:
            raise e

    @staticmethod
    def one_key(key):
        """模拟单个按键"""
        try:
            KeyBoardKeys.key_down(key)
            KeyBoardKeys.key_up(key)
        except Exception as e:
            raise e

    @staticmethod
    def two_keys(key1, key2):
        """模拟组合按键"""
        try:
            KeyBoardKeys.key_down(key1)
            KeyBoardKeys.key_down(key2)
            KeyBoardKeys.key_up(key1)
            KeyBoardKeys.key_up(key2)
        except Exception as e:
            raise e

    @staticmethod
    def three_keys(key1, key2, key3):
        """模拟组合按键"""
        try:
            KeyBoardKeys.key_down(key1)
            KeyBoardKeys.key_down(key2)
            KeyBoardKeys.key_down(key3)
            KeyBoardKeys.key_up(key1)
            KeyBoardKeys.key_up(key2)
            KeyBoardKeys.key_up(key3)
        except Exception as e:
            raise e


keyboard = KeyBoardKeys()
