#!/usr/bin/env python3
# coding=utf-8
"""
@File    : system_application_operation.py
@Time    : 2022/3/30 14:38
@Author  : base_test
@Explain : 打开系统应用
@Software: PyCharm
"""

'''
hwnd = win32gui.FindWindow(lpClassName=None, lpWindowName=None)  # 查找窗口，不找子窗口，返回值为0表示未找到窗口
hwnd = win32gui.FindWindowEx(hwndParent=0, hwndChildAfter=0, lpszClass=None, lpszWindow=None)  # 查找子窗口，返回值为0表示未找到子窗口

win32gui.ShowWindow(hwnd, win32con.SW_SHOWNORMAL)
SW_HIDE：隐藏窗口并激活其他窗口。nCmdShow=0。
SW_SHOWNORMAL：激活并显示一个窗口。如果窗口被最小化或最大化，系统将其恢复到原来的尺寸和大小。应用程序在第一次显示窗口的时候应该指定此标志。nCmdShow=1。
SW_SHOWMINIMIZED：激活窗口并将其最小化。nCmdShow=2。
SW_SHOWMAXIMIZED：激活窗口并将其最大化。nCmdShow=3。
SW_SHOWNOACTIVATE：以窗口最近一次的大小和状态显示窗口。激活窗口仍然维持激活状态。nCmdShow=4。
SW_SHOW：在窗口原来的位置以原来的尺寸激活和显示窗口。nCmdShow=5。
SW_MINIMIZE：最小化指定的窗口并且激活在Z序中的下一个顶层窗口。nCmdShow=6。
SW_SHOWMINNOACTIVE：窗口最小化，激活窗口仍然维持激活状态。nCmdShow=7。
SW_SHOWNA：以窗口原来的状态显示窗口。激活窗口仍然维持激活状态。nCmdShow=8。
SW_RESTORE：激活并显示窗口。如果窗口最小化或最大化，则系统将窗口恢复到原来的尺寸和位置。在恢复最小化窗口时，应用程序应该指定这个标志。nCmdShow=9。
'''

from public_functions import get_config_value
import os
from public_functions import log, wait


def open_wx_work_app():
    wx_work_app_dir = get_config_value('WX_Work_Position', 'lijing_machine')
    os.startfile(wx_work_app_dir)  # os.startfile（）打开外部应该程序，与windows双击相同


def find_system_windows(window_class, window_name, retry_num=0):
    try:
        import win32gui
        import win32con
    except Exception as e:
        log.error('获取模块win32gui和win32con失败，具体报错信息如下：' + str(e))
    else:
        # 在刚打开的时候会找不到弹窗，必须强制等待2秒，具体时间根据设备性能决定
        time_num = 1
        wait(time_num)
        dialog = win32gui.FindWindow(window_class, window_name)  # 对话框
        print('dialog==>' + str(dialog))
        if dialog == 0:
            raise Exception('等待了%d秒未见弹窗，请检查弹窗是否有效' % time_num)
        else:
            print('继续')


def minimize_window(window_class, retry_num=0):
    pass


if __name__ == '__main__':
    open_wx_work_app()