#!/usr/bin/env python3
# coding=utf-8
"""
@File    : system_upload.py
@Time    : 2021/12/30
@Author  : bese_test
@Explain : UI自动化系统上传文件操作类
@Software: PyCharm
"""
import os
from public_functions import log, wait


# 选择上传文件
def choose_upload_file(directory, file_name, retry_num=0):
    """
    :param directory: 上传文仔所在目录，window示例："E:\\school_file\\"
    :param file_name: 文件名称
    :return:
    """
    try:
        import win32gui
        import win32con
        # 在刚打开的时候会找不到弹窗，必须强制等待2秒，具体时间根据设备性能决定
        time_num = 2
        if retry_num == 0:
            wait(time_num)
        else:
            wait(time_num + 2)
        dialog = win32gui.FindWindow('#32770', '打开')  # 对话框
        if dialog == 0:
            if retry_num == 0:
                log.warning('等待时间太短，无法找到元素，即将重新请求')
                choose_upload_file(directory, file_name, 1)
                return
            else:
                log.error('等待了四秒未见弹窗，请检查弹窗是否有效')
                raise Exception('等待了%d秒未见弹窗，请检查弹窗是否有效' % time_num+2)
        combobox_ex32 = win32gui.FindWindowEx(dialog, 0, 'ComboBoxEx32', None)
        combobox = win32gui.FindWindowEx(combobox_ex32, 0, 'ComboBox', None)
        edit = win32gui.FindWindowEx(combobox, 0, 'Edit', None)  # 上面三句依次寻找对象，直到找到输入框Edit对象的句柄
        button = win32gui.FindWindowEx(dialog, 0, 'Button', None)  # 确定按钮Button
        file = os.path.join(directory, str(file_name))
        win32gui.SendMessage(edit, win32con.WM_SETTEXT, None, file)  # 往输入框输入绝对地址
        win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)  # 按button
        log.info('文件%s目录输入成功' % str(file))
    except Exception as e:
        log.error('获取模块win32gui和win32con失败，具体报错信息如下：' + str(e))
