#!/usr/bin/env python3
# coding=utf-8
"""
@File    : system_or_project_function
@Time    : 2022/1/1
@Author  : base_test
@Explain : 项目或系统操作类
@Software: PyCharm
"""

import configparser
import platform
import os
import win32clipboard as w
import win32con


# 获取操作系统类型
def get_system_type():
    """
    :return: 操作系统类型：Windows；Linux；Mac os
    """
    sys_type = platform.system()
    return sys_type


# 获取运行文件路径
def get_root_path(need_files=False):
    # 获取当前文件的目录
    cur_path = os.path.abspath(os.path.dirname(__file__))
    root_path = os.path.dirname(cur_path)  # 获取当前文件的目录的上一级目录
    try:
        system_type = get_system_type()
        if system_type == 'Windows':
            root_path += '\\'
            if need_files:
                root_path += 'files\\'
        elif system_type == 'Linux':
            root_path += '/'
            if need_files:
                root_path += 'files/'
        else:
            raise Exception('该系统类型暂时不支持' + str(system_type))
        return root_path
    except Exception as e:
        AssertionError('获取根目录错误，错误信息为：' + str(e))


# 获取files文件路径
def get_files_path():
    return get_root_path(True)


# 获取配置文件类
def get_config_value(key, param, filepath=None):
    """
    :param key: config文件的[属性值]
    :param param: 属性值下面的具体参数
    :param filepath: 项目根目录下其他配置文件，起始位置为项目根目录开始找
    :return: 属性值下参数对应的值
    """
    cf = configparser.ConfigParser()
    try:
        if filepath is None:
            config_file = os.path.join(get_root_path(), 'config.ini')
        else:
            config_file = os.path.join(get_root_path(), filepath)
        cf.read(config_file, encoding='UTF-8')
    except Exception as e:
        AssertionError('获取config.ini配置文件失败' + str(e))
    try:
        if key is None:
            AssertionError('获取配置的属性名不能为空')
        elif param is None:
            AssertionError('获取配置的属性名的参数值不能为空')
        else:
            value = cf.get(key, param)
            return value
    except Exception as e:
        AssertionError('获取配置文件失败，属性值或者参数错误' + str(e))


# 获取系统存放日志和截图以及报告的位置，如果不存在则创建文件夹存放
def get_system_result_directory():
    """
    :return: {
        'screenshot_directory': screenshot_directory, # 截图存放路径
        'logs_directory': logs_directory,  # 日志存放路径
        'reports_directory': reports_directory  # 报告存放路径
    }
    """
    dirname = get_root_path()
    dirname = os.path.join(dirname, 'UI_TEST_RESULT')
    screenshot_directory = os.path.join(dirname, 'screenshot_pictures')
    reports_directory = os.path.join(dirname, 'report')
    screentshot_is_exist = os.path.isdir(screenshot_directory)
    reports_is_exist = os.path.isdir(reports_directory)
    try:
        if not screentshot_is_exist:
            os.mkdir(screenshot_directory)
        if not reports_is_exist:
            os.mkdir(reports_directory)
    except Exception as e:
        raise Exception('创建截屏目录或报告目录失败' + str(e))
    return {
        'screenshot_directory': screenshot_directory,
        'reports_directory': reports_directory
    }


def get_clipboard_text():
    w.OpenClipboard()
    d = w.GetClipboardData(win32con.CF_TEXT)
    w.CloseClipboard()
    return d.decode('GBK')


def set_clipboard_text(data):
    w.OpenClipboard()
    w.EmptyClipboard()
    w.SetClipboardData(win32con.CF_TEXT, data)
    w.CloseClipboard()


def joint_path(dirname, child_directory):
    """
    拼接路径
    :param dirname:主路径，其他的都是拼接在他的后面
    :param child_directory:需要拼接的子目录
    :return: 拼接后的结果
    """
    if child_directory:
        try:
            dirname = os.path.join(dirname, child_directory)
        except Exception as e:
            raise Exception('拼接子目录失败，具体原因如下：')
    return dirname


if __name__ == '__main__':
    data = get_system_result_directory()
    print(data)
