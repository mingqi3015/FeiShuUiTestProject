#!/usr/bin/env python3
# coding=utf-8
"""
@File    : helper.py
@Time    : 2022/1/1
@Author  : base_test
@Explain : 函数助手
@Software: PyCharm
"""

import re
import random
import string
from faker import Factory

faker = Factory().create('zh_CN')
default_elements = string.ascii_letters + string.digits


def Unicode():
    val = random.randint(0x4e00, 0x9fbf)
    return chr(val)


def rand_text(length=10):
    """
    随机生成汉字
    :return:
    """
    result = ''
    for i in range(length):
        result += Unicode()
    return result


def rand_int(min_=1, max_=100):
    """
    随机生成整数
    :param min_:
    :param max_:
    :return:
    """
    return faker.random.randint(min_, max_)


def rand_special_word(length=10):
    """随机生成特殊字符,特殊字符一共有32个"""
    all_special_word = []
    for i in string.punctuation:
        all_special_word.append(i)
    result = ''
    for i in range(length):
        result += all_special_word[rand_int(0, 31)]
    return result


def rand_word(length=10):
    """
    随机生成字母
    :param length:
    :return:
    """
    return ''.join(faker.random_letters(length=length))


def rand_string(elements=default_elements, length=10):
    """
    随机生成字符（英文+数字）
    :param elements:
    :param length:
    :return:
    """
    return ''.join(faker.random_choices(elements=str(elements), length=length))


def rand_phone_number():
    """
    随机生成手机号
    :return:
    """
    return faker.phone_number()


def rand_name():
    """
    随机生成名字
    :return:
    """
    return faker.name()


def rand_address():
    """
    随机生成所在地址
    :return:
    """
    return faker.address()


def rand_country():
    """
    随机生成国家名
    :return:
    """
    return faker.country()


def rand_country_code():
    """
    随机生成国家代码
    :return:
    """
    return ''.join(faker.country_code())


def rand_city_name():
    """
    随机生成城市名
    :return:
    """
    return faker.city_name()


def rand_city():
    """
    随机生成城市
    :return:
    """
    return faker.city()


def rand_province():
    """
    随机生成省份
    :return:
    """
    return faker.province()


def rand_email():
    """
    随机生成email
    :return:
    """
    return faker.email()


def rand_ipv4():
    """
    随机生成IPV4地址
    :return:
    """
    return faker.ipv4()


def rand_lipate():
    """
    随机生成车牌号
    :return:
    """
    return faker.license_plate()


def rand_color():
    """
    随机生成颜色
    :return:
    """
    return faker.rgb_color()


def rand_safe_hex_color():
    """
    随机生成16进制的颜色
    :return:
    """
    return faker.safe_hex_color()


def rand_color_name():
    """
    随机生成颜色名字
    :return:
    """
    return faker.color_name()


def rand_company_name():
    """
    随机生成公司名
    :return:
    """
    return faker.company()


def rand_job():
    """
    随机生成工作岗位
    :return:
    """
    return faker.job()


def rand_password(length=10, special_chars=True, digits=True, upper_case=True, lower_case=True):
    """
    随机生成密码
    :param lower_case:
    :param upper_case:
    :param digits:
    :param special_chars:
    :param length:
    :return:
    """
    return faker.password(length=length, special_chars=special_chars, digits=digits, upper_case=upper_case,
                          lower_case=lower_case)


def rand_uuid4():
    """
    随机生成uuid
    :return:
    """
    return faker.uuid4()


def rand_sha1(raw_output=False):
    """
    随机生成sha1
    :return:
    """
    return faker.sha1(raw_output=raw_output)


def rand_md5(raw_output=False):
    """
    随机生成md5
    :return:
    """
    return faker.md5(raw_output=raw_output)


def rand_female():
    """
    随机生成女性名字
    :return:
    """
    return faker.name_female()


def rand_male():
    """
    随机生成男性名字
    :return:
    """
    return faker.name_male()


def rand_user_info(sex=None):
    """
    随机生成粗略的基本信息
    :return:
    """
    return faker.simple_profile(sex=sex)


def rand_user_information(fields=None, sex=None):
    """
    随机生成详细的基本信息
    :return:
    """
    return faker.profile(fields=fields, sex=sex)


def rand_user_agent():
    """
    随机生成浏览器头user_agent
    :return:
    """
    return faker.user_agent()


def setEncryptVars(method, target_key):
    """
    给参数加密
    :param method: 加密风格 base64 md5 sha1
    :param target_key:
    :return:
    Example::
        >>> print(setEncryptVars("md5", "${rand_nt}"))
        >>> print(setEncryptVars("sha1", "$VAR_TEST_001"))
        >>> print(setEncryptVars("base64", "{{Custom_NULL_VAR}}"))
    """
    func_list = ["base64", "md5", "sha1"]
    if method in func_list:
        exec('_var = CipherHelper().{method}Encrypt("{target_key}")'.format(method=method,
                                                                            target_key=cite_helper(target_key)))
        var = locals()["_var"]
        return var.decode() if isinstance(var, bytes) else var
    else:
        raise ModuleNotFoundError("暂时仅支持：%s" % (", ".join(func_list)))


func_dict = {"Int": rand_int,
             "word": rand_word(),
             "String": rand_string(),
             "Phone_number": rand_phone_number(),
             "Name": rand_name,
             "Address": rand_address,
             "Country": rand_country,
             "CountryCode": rand_country_code,
             "CityName": rand_city_name,
             "City": rand_city,
             "Province": rand_province,
             "Email": rand_email,
             "Ipv4": rand_ipv4,
             "Lipate": rand_lipate,
             "Color": rand_color,
             "SafeHexColor": rand_safe_hex_color,
             "ColorName": rand_color_name,
             "CompanyName": rand_company_name,
             "Job": rand_job,
             "Pwd": rand_password(),
             "Uuid4": rand_uuid4,
             "Sha1": rand_sha1,
             "Md5": rand_md5,
             "Female": rand_female,
             "Male": rand_male,
             "UserInfo": rand_user_info,
             "UserInfoPro": rand_user_information,
             "UserAgent": rand_user_agent
             }


def cite_helper(name: str):
    """
    函数助手，输出以下常用随机数，返回结果值。支持的函数详情见func_dict:
    :param name:  函数名，需要在func_dict存在的key值
    :return:  随机函数调用结果 or None
    Example::
        >>> print(citeHelper('${rand_int()}'))
        >>> print(citeHelper('${randLetters(5)}'))
        >>> print(citeHelper('${randSample(123567890,30)}'))
        >>> print(citeHelper("${getUserVars()}"))
        >>> print(citeHelper("${getUserVars(randPwd)}"))
        >>> print(citeHelper("{{UserAgent}}"))
        >>> print(citeHelper("{{Custom_None_VAR}}"))
        >>> print(citeHelper("{{Custom_NULL_VAR}}"))
        >>> print(citeHelper("$VAR_TEST_001"))
        >>> print(citeHelper('$ENC_(base64,Base64参数加密)'))
    """
    # fix: File "D:\Program Files\Python37\lib\re.py", line 173, in match
    # return _compile(pattern, flags).match(string)
    # TypeError: expected string or bytes-like object
    rand_vars = re.match("\$\{rand(.*)\((.*)\)\}", str(name))  # 带参数
    rand_no_vars = re.match("\$\{rand(.*)\}", str(name))  # 无参数
    dynamic_vars = re.match("\$\{get(.*)\((.*)\)\}", str(name))  # 动态自定义
    own_vars = re.match("\{\{(.*)\}\}", str(name))  # 动态自定义
    extract_vars = re.match("\$VAR_(.*)", str(name).upper())  # 后置提取参数
    lock_vars = re.match("\$ENC_(.*)", str(name))  # 带参数
    pattern = rand_vars if rand_vars is not None else dynamic_vars
    if pattern is not None:
        key, value = pattern.groups()
        if func_dict.get(key):
            func = func_dict[key]
            _param = [eval(x) if x.strip().isdigit() else x for x in value.split(',')]
            if len(_param) >= 1 and "" not in _param:
                return func.__call__(*_param)
            elif "" in _param:
                return func.__call__()  # 没有带参数的
    elif rand_no_vars:
        return func_dict[rand_no_vars.group().strip("${rand}")].__call__()
    elif lock_vars:
        _lock_param = [eval(x) if x.strip().isdigit() else x for x in lock_vars.group().strip("$ENC_()").split(',')]
        if len(_lock_param) < 2:
            raise IndexError(_lock_param)
        else:
            return setEncryptVars.__call__(*_lock_param)
    else:
        return name  # 函数名不存在返回原始值


def comb_data(dict_map: dict) -> dict:
    """
    合并参数化数据
    :param dict_map: 初始data dict类型
    举例 {"product": {"brand_id": "${rand_int(1,2)}", "category_id": '${randFloat(1,2,3)}',"test": {"test": "${randSample(123567890abc,30)}"}}}
    转化后 {'product': {'brand_id': 7, 'category_id': 1.358, 'test': {'test': 'c071135252718592b58007a10093b6'}}}
    :return 转化后的数据 若无则返回原始值
    Example::
        >>> print(combData({"product": {"brand_id": "{{Int}}", "category_id": '${randFloat(1,2,3)}' }}))
        >>> print(combData({"create_time": "${randTime(10timestamp)}"}))
        >>> print(combData({"key1":"$ENC_(base64,Base64参数加密)"}))
    """
    if isinstance(dict_map, dict):
        for key in list(dict_map.keys()):
            if isinstance(dict_map[key], list):
                for i in range(len(dict_map[key])):
                    dict_map[key][i] = comb_data(dict_map=dict_map[key][i])
            elif isinstance(dict_map[key], dict):
                dict_map[key] = comb_data(dict_map=dict_map[key])
            else:
                dict_map[key] = cite_helper(dict_map[key])
        return dict_map
    elif dict_map is None:  # fix：为空的时候raise 异常导致其它函数调用失败
        pass


if __name__ == '__main__':
    print(rand_name())
    print(rand_word())
    print(rand_string())
    print(rand_password())
