# -*- encoding: utf-8 -*-
"""
@File    : functions.py
@Time    : 2021/12/30
@Author  : base_test
@Explain : 常用方法函数
@Software: PyCharm
"""
import random
import os
import cv2
import requests
import shutil
from time import time, sleep, strftime, localtime
from functools import wraps
from public_functions import TxtOperation, get_system_type, get_root_path
from datetime import datetime
from public_functions.beautiful_log import log



def wait(s=.5):
    """
    强制等待
    :param s: 等待时间（Float类型）
    :return: 无
    """
    sleep(float(s))


def get_current_time():
    this_time = strftime("%Y-%m-%d %H.%M.%S", localtime())
    return this_time


def task_run_time(a_func):
    """
    函数执行时间装饰器，会输出任务执行时间
    :param a_func:
    :return: 函数执行结果
    使用示例：
    @task_run_time
    def get_result():
        wait(3)
    get_result()
    输出：任务执行时间为3秒
    """

    @wraps(a_func)
    def decorated(*args, **kwargs):
        start_time = time()
        data = a_func(*args, **kwargs)
        stop_time = time()
        total_second = stop_time - start_time
        total_minutes, surplus_second = divmod(total_second, 60)
        hour, surplus_minutes = divmod(total_minutes, 60)
        log.info("任务执行用时：%02d时:%02d分:%02d秒" % (hour, surplus_minutes, surplus_second))
        return data

    return decorated


def get_ip(url):
    """
    根据url获取ip地址
    :param url: 需要获取到url
    :return: 返回ip地址
    """
    response = requests.get(url=url, stream=True)
    return response.raw.connection.sock.getpeername()[0]


# 获取当前路径或者获取参数路径的上一级路径
def get_current_path(child_directory=None):
    """
    :param child_directory: 路径
    :return: 当前路径或者参数路径的上一级
    """
    if child_directory:
        try:
            parent_path = os.path.dirname(child_directory)
            return parent_path
        except Exception as e:
            log.error('获取路径上一级失败，具体原因如下：')
            log.error(e)
    else:
        current_path = os.getcwd()
        return current_path


# 随机在oldlist里面找一个值添加到resultlist里面，不能重复，返回添加之后的数组
def old_list_random_num_join_new_list(result_list, old_list):
    item = get_list_random_value(old_list)
    if item in result_list:
        result_list = old_list_random_num_join_new_list(result_list, old_list)
    else:
        result_list.append(item)
    return result_list


def joint_path(dirname, child_directory):
    """
    拼接路径
    :param dirname:主路径，其他的都是拼接在他的后面
    :param child_directory:需要拼接的子目录
    :return: 拼接后的结果
    """
    if child_directory:
        try:
            dirname = os.path.join(dirname, child_directory)
        except Exception as e:
            log.error('拼接子目录失败，具体原因如下：')
            log.error(e)
    return dirname


def add_data_to_url(data, url):
    """
    将data字典里面的值拼接到url里面，返回url
    :param data: 字典，url后面的参数键值对
    :param url: 前面的url
    :return: 拼接后的结果
    """
    keys_length = len(data.keys())
    for i, item in enumerate(data):
        # 只要一个参数时
        if keys_length - 1 is 0:
            url += '?' + item + '=' + data[item]
        # 不止一个参数时的第一个参数拼接
        elif i is 0:
            url += '?' + item + '=' + data[item] + '&'
        # 不止一个参数时的最后一个参数拼接
        elif i == keys_length - 1:
            url += item + '=' + data[item]
        # 其他情况
        else:
            url += item + '=' + data[item] + '&'
    return url


def dec2hex(hex_str):
    """
    字符串转16进制
    :param hex_str: 需要转换的字符串
    :return:
    """
    return format(int(hex(int(hex_str)), 16), 'x')


def split_value(data, str1):
    """
    根据字符串截取字符串，返回数组
    :param data: 需要截取的字符串
    :param str1: 以什么为介质截取
    :return: 返回列表
    """
    num = data.count(str1)
    if num != 0:
        index = data.index(str1)
        result_data = []
        # 如果是最后一个需要将两个值都返回
        if num == 1:
            data1 = judge_is_contain_list(data[:index])
            data2 = judge_is_contain_list(data[index + 1:])
            for i in data1:
                result_data.append(i)
            for j in data2:
                result_data.append(j)
        # 如果不是最后一个则先将前面一个加到现有的里面，然后继续操作
        else:
            # 判断当前键是否含有中括号
            data1 = judge_is_contain_list(data[:index])
            for i in data1:
                result_data.append(i)
            # 获取截取之后的字符串并进行递归
            after_data = data[index + 1:]
            result_data += split_value(after_data, str1)
        return result_data
    else:
        log.info(data + '字符串中不存在:' + str1)


def judge_is_contain_list(str1):
    """
    判断是否含有列表类型
    忘记了
    :param str1:
    :return:
    """
    result = []
    # 判断是否含有方括号并且只有一对方括号
    if str1.count('[') == str1.count(']') and str1.count(']') != 0:
        index1 = str1.index('[')
        index2 = str1.index(']')
        # 如果传入值仅只有一个方括号加值例如：[1]
        if index1 == 0:
            result.append(int(str1[index1 + 1:index2]))
        # 传入值是一个完整的值时例如：name[1]先返回name
        else:
            result.append(str1[:index1])
            result.append(int(str1[index1 + 1:index2]))
        # 如果含有方括号但是不止一对方括号时则 递归
        if str1.count('[') > 1:
            index1 = str1.index(']')
            result2 = judge_is_contain_list(str1[index1 + 1:])
            for i in result2:
                result.append(int(i))
    # 其他情况视为不需要操作
    else:
        result = [str1]
    return result


def get_dictionary_value(data, value):
    """
    # 根据表达式获取字典中的具体值 json_path = '$.data.member.name[1].token'
    :param data: 字典
    :param value: '$.data.member.name[1].token'
    :return:
    """
    # 根据点来截取表达式
    str1 = split_value(value, '.')
    if type(data) is dict:
        result_data = data
        for index, item in enumerate(str1):
            if index != 0:
                try:
                    result_data = result_data[item]
                except KeyError:
                    result_data = None
                except TypeError:
                    result_data = None
                except IndexError:
                    result_data = None
        return result_data
    else:
        log.info('传参必须是字典形式')
        return data


def get_this_time():
    """
    获取当前时间戳
    :return: String类型
    """
    return get_current_time()


def random_int_number(min_num, max_num):
    return random.randint(int(min_num), int(max_num))


def get_list_random_value(data):
    """获取列表随机选项"""
    if type(data) is list:
        data_len = len(data)
        index = random_int_number(0, data_len - 1)
        return data[index]
    else:
        raise Exception('参数类型错误，需要传入列表类型')


def find_fail_case(report_positon, need_exception=False):
    """
    在html文件里面查找失败用例
    :param report_positon: html报告文件位置
    :param need_exception: 是否需要丢出错误
    :return:
    """
    fail_str = '"testFail": '
    error_str = '"testError": '
    html_content = TxtOperation(report_positon).get_txt()
    fail_index = html_content.index(fail_str)
    error_index = html_content.index(error_str)
    fail_length = len(fail_str)
    error_length = len(error_str)
    fail_end_index = fail_index + fail_length
    error_end_index = error_index + error_length
    fail_num = html_content[fail_end_index: fail_end_index + 1]
    error_num = html_content[error_end_index: error_end_index + 1]
    if need_exception:
        try:
            fail_num = int(fail_num)
        except:
            fail_num = 0
        try:
            error_num = int(error_num)
        except:
            error_num = 0
        if fail_num > 0 or error_num > 0:
            raise Exception('有错误或者失败用例，请查看报告')
        else:
            log.info('用例没有报错或者执行失败，全部用例通过')
    else:
        result_data = {
            'fail_num': fail_num,
            'error_num': error_num
        }
        return result_data


def cv_imread(file_path):
    """
    转换路径给opencv-python用
    :param file_path:
    :return:
    """
    root_dir, file_name = os.path.split(file_path)
    pwd = os.getcwd()
    if root_dir:
        os.chdir(root_dir)
    cv_img = cv2.imread(file_name)
    os.chdir(pwd)
    return cv_img


def rmdir_report_and_result_dir():
    report_dir = 'UI_TEST_RESULT\\report\\html' if get_system_type() == 'Windows' else 'UI_TEST_RESULT/report/html'
    report_dir = get_root_path() + report_dir
    result_dir = 'UI_TEST_RESULT\\report\\result' if get_system_type() == 'Windows' else 'UI_TEST_RESULT/report/result'
    result_dir = get_root_path() + result_dir
    if os.path.isdir(report_dir):
        rmdir(report_dir)
        log.info('删除report目录成功')
    if os.path.isdir(result_dir):
        rmdir(result_dir)
        log.info('删除result目录成功')


# 移除文件夹
def rmdir(path):
    shutil.rmtree(path, ignore_errors=True)


if __name__ == '__main__':
    print(get_current_time())
    print(get_this_time())
    pass
